import { useState, useCallback, useRef, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useSendChatMessage, usePredictHealth } from '@workspace/api-client-react';
import type {
  VitalsInput,
  PredictionResult,
  ChatResponseNextStep,
  ChatMessage as ApiChatMessage
} from '@workspace/api-client-react';
import { useToast } from '@/hooks/use-toast';
import type { VoiceLang } from '@/hooks/use-voice';

export type Message = {
  id: string;
  role: 'user' | 'bot';
  text: string;
};

export function useHealthAssistant(lang: VoiceLang) {
  const [sessionId, setSessionId] = useState<string>(() => uuidv4());
  const [messages, setMessages] = useState<Message[]>([]);
  const [nextStep, setNextStep] = useState<ChatResponseNextStep>('greeting');
  const [isTyping, setIsTyping] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const { toast } = useToast();
  const initialized = useRef(false);
  const latestLang = useRef(lang);

  const chatMutation = useSendChatMessage();
  const predictMutation = usePredictHealth();

  // Keep lang ref up to date
  useEffect(() => { latestLang.current = lang; }, [lang]);

  useEffect(() => {
    if (!initialized.current) {
      initialized.current = true;
      handleSendMessage("Hello", true);
    }
  }, []);

  const resetSession = useCallback(() => {
    const newId = uuidv4();
    setSessionId(newId);
    setMessages([]);
    setNextStep('greeting');
    setIsScanning(false);
    setPrediction(null);
    setTimeout(() => {
      // Trigger greeting with new session
      const payload: ApiChatMessage = { message: "Hello", sessionId: newId, language: latestLang.current };
      chatMutation.mutateAsync({ data: payload }).then((response) => {
        const r = response as { reply: string; nextStep: ChatResponseNextStep };
        setMessages([{ id: uuidv4(), role: 'bot', text: r.reply }]);
        setNextStep(r.nextStep);
      }).catch(() => {});
    }, 100);
  }, []);

  const runPrediction = async (vitals: VitalsInput) => {
    setIsScanning(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      const result = await predictMutation.mutateAsync({ data: vitals });
      setPrediction(result);
    } catch {
      toast({ title: "Prediction Error", description: "Failed to analyze vitals. Please try again.", variant: "destructive" });
    } finally {
      setIsScanning(false);
    }
  };

  const handleSendMessage = async (text: string, isSystemInit = false) => {
    if (!text.trim()) return;

    if (!isSystemInit) {
      setMessages(prev => [...prev, { id: uuidv4(), role: 'user', text }]);
    }

    setIsTyping(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      const payload: ApiChatMessage = { message: text, sessionId, language: latestLang.current };
      const response = await chatMutation.mutateAsync({ data: payload });

      setMessages(prev => [...prev, { id: uuidv4(), role: 'bot', text: response.reply }]);
      setNextStep(response.nextStep);

      if (response.vitalsReady && response.vitals) {
        runPrediction(response.vitals as VitalsInput);
      }
    } catch {
      toast({ title: "Connection Error", description: "Could not reach the assistant.", variant: "destructive" });
      setMessages(prev => [...prev, {
        id: uuidv4(), role: 'bot',
        text: lang === 'te' ? "నెట్‌వర్క్ సమస్య వచ్చింది. దయచేసి మళ్ళీ ప్రయత్నించండి." : "I'm having trouble connecting right now. Please try again."
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  // Return the latest bot message text (for TTS)
  const latestBotMessage = messages.filter(m => m.role === 'bot').at(-1)?.text ?? '';

  return {
    sessionId, messages, nextStep, isTyping, isScanning, prediction,
    latestBotMessage,
    sendMessage: handleSendMessage,
    resetSession,
  };
}
