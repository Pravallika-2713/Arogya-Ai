import { motion } from "framer-motion";
import { User, Activity } from "lucide-react";
import { clsx } from "clsx";
import type { Message } from "@/hooks/use-health-assistant";

interface ChatMessageProps {
  message: Message;
}

export function ChatMessageBubble({ message }: ChatMessageProps) {
  const isBot = message.role === 'bot';

  return (
    <motion.div
      initial={{ opacity: 0, y: 15, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={clsx(
        "flex w-full mb-6",
        isBot ? "justify-start" : "justify-end"
      )}
    >
      <div className={clsx("flex max-w-[85%] md:max-w-[75%]", isBot ? "flex-row" : "flex-row-reverse")}>
        
        {/* Avatar */}
        <div className={clsx(
          "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center shadow-md border-2 border-background z-10",
          isBot ? "bg-primary text-primary-foreground mr-3" : "bg-accent text-accent-foreground ml-3"
        )}>
          {isBot ? (
             <img 
               src={`${import.meta.env.BASE_URL}images/ai-avatar.png`} 
               alt="AI Doctor" 
               className="w-full h-full object-cover rounded-full"
               onError={(e) => { e.currentTarget.style.display='none'; }}
             />
          ) : (
            <User size={20} />
          )}
        </div>

        {/* Bubble */}
        <div className={clsx(
          "px-5 py-4 rounded-2xl shadow-sm relative",
          isBot 
            ? "bg-white text-foreground rounded-tl-none border border-border/50" 
            : "bg-primary text-primary-foreground rounded-tr-none shadow-primary/20"
        )}>
          {isBot && (
            <div className="absolute top-0 -left-2 w-4 h-4 bg-white border-l border-t border-border/50 clip-triangle" />
          )}
          <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{message.text}</p>
        </div>
      </div>
    </motion.div>
  );
}

export function TypingIndicator() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex w-full justify-start mb-6"
    >
      <div className="flex flex-row max-w-[80%]">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary text-primary-foreground mr-3 flex items-center justify-center shadow-md border-2 border-background z-10">
          <Activity size={20} className="animate-pulse" />
        </div>
        <div className="px-5 py-4 rounded-2xl bg-white text-foreground rounded-tl-none shadow-sm border border-border/50 flex items-center space-x-1.5 h-[56px]">
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0 }} className="w-2 h-2 bg-primary/60 rounded-full" />
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }} className="w-2 h-2 bg-primary/60 rounded-full" />
          <motion.div animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }} className="w-2 h-2 bg-primary/60 rounded-full" />
        </div>
      </div>
    </motion.div>
  );
}
