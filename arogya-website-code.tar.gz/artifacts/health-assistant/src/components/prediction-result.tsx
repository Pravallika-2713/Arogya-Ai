import { motion } from "framer-motion";
import {
  AlertCircle, CheckCircle, Heart,
  ClipboardList, RefreshCw, Activity, Leaf, ShieldCheck, Phone, User
} from "lucide-react";
import type { PredictionResult, Specialist } from "@workspace/api-client-react";
import type { VoiceLang } from "@/context/app-context";
import { AppointmentBooking } from "./appointment-booking";
import { SubsidySchemes } from "./subsidy-schemes";
import { REMEDIES, type Disease } from "@/data/remedies";

interface PredictionResultProps {
  prediction: PredictionResult;
  onReset: () => void;
  lang: VoiceLang;
}

const DISEASE_COLORS: Record<string, string> = {
  "Healthy":            "from-emerald-400 to-teal-600",
  "Asthma":             "from-blue-400 to-indigo-600",
  "Heart Disease":      "from-rose-500 to-red-700",
  "Hypertension":       "from-orange-400 to-red-500",
  "Diabetes Mellitus":  "from-amber-400 to-orange-600",
};

const DISEASE_ICONS: Record<string, string> = {
  "Healthy":            "💚",
  "Asthma":             "🌬️",
  "Heart Disease":      "❤️",
  "Hypertension":       "🩺",
  "Diabetes Mellitus":  "🩸",
};

const DISEASE_NAMES_TE: Record<string, string> = {
  "Healthy":            "ఆరోగ్యంగా ఉన్నారు",
  "Asthma":             "ఆస్తమా",
  "Heart Disease":      "గుండె జబ్బు",
  "Hypertension":       "అధిక రక్తపోటు",
  "Diabetes Mellitus":  "డయాబెటిస్",
};

const RISK_BADGE: Record<string, string> = {
  low:    "bg-yellow-100 text-yellow-700 border-yellow-200",
  medium: "bg-orange-100 text-orange-700 border-orange-200",
  high:   "bg-red-100   text-red-700    border-red-200",
};

const SPECIALIST_COLORS = [
  "bg-blue-50 border-blue-200",
  "bg-purple-50 border-purple-200",
  "bg-rose-50 border-rose-200",
  "bg-teal-50 border-teal-200",
];

function AlertBadge({ label, status }: { label: string; status: string }) {
  const isAbnormal = status === "ABNORMAL";
  return (
    <div className={`flex items-center justify-between px-4 py-2.5 rounded-xl border text-sm font-medium
      ${isAbnormal ? "bg-red-50 border-red-200 text-red-700" : "bg-emerald-50 border-emerald-200 text-emerald-700"}`}>
      <span>{label}</span>
      <span className={`text-xs font-bold tracking-wider px-2 py-0.5 rounded-full
        ${isAbnormal ? "bg-red-100" : "bg-emerald-100"}`}>
        {status}
      </span>
    </div>
  );
}

function Section({
  icon, title, color, children
}: { icon: React.ReactNode; title: string; color: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-2 ${color}`}>
        {icon}{title}
      </h3>
      {children}
    </div>
  );
}

export function PredictionResultCard({ prediction, onReset, lang }: PredictionResultProps) {
  const isRisk = prediction.status === "At Risk";
  const gradientClass = DISEASE_COLORS[prediction.disease] ?? "from-teal-400 to-teal-600";
  const diseaseIcon = DISEASE_ICONS[prediction.disease] ?? "🏥";
  const displayName = lang === "te"
    ? (DISEASE_NAMES_TE[prediction.disease] ?? prediction.disease)
    : prediction.disease;

  // ── Use bilingual remedies from frontend data ──────────────────────────
  const localRemedies = REMEDIES[prediction.disease as Disease]?.[lang];
  const homeRemedies = localRemedies?.homeRemedies ?? prediction.homeRemedies ?? [];
  const precautions  = localRemedies?.precautions  ?? prediction.precautions  ?? [];

  const v = { hidden: { opacity: 0, y: 14 }, visible: { opacity: 1, y: 0 } };

  const resetLabel = lang === "te" ? "కొత్త పరీక్ష మొదలు పెట్టండి" : "Start New Assessment";

  return (
    <motion.div
      initial="hidden" animate="visible" variants={v}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="w-full max-w-2xl mx-auto bg-white rounded-3xl shadow-xl border border-border overflow-hidden"
    >
      {/* ── Gradient Header ─────────────────────────────────────────── */}
      <div className={`p-8 text-center text-white relative overflow-hidden bg-gradient-to-br ${gradientClass}`}>
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "radial-gradient(circle at 20% 150%, white 0%, transparent 50%)" }} />
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, delay: 0.3 }}
          className="text-5xl mb-4">{diseaseIcon}</motion.div>
        <p className="text-xs font-bold tracking-widest uppercase opacity-80 mb-1">
          {lang === "te" ? "Arogya AI అంచనా" : "Arogya AI Prediction"}
        </p>
        <h1 className="text-3xl font-bold tracking-tight mb-1">{displayName}</h1>
        <p className="text-sm opacity-80">
          {lang === "te" ? "స్థితి: " : "Overall Status: "}
          <strong>{isRisk ? (lang === "te" ? "ప్రమాదంలో ఉంది" : "At Risk") : (lang === "te" ? "సాధారణం" : "Normal")}</strong>
        </p>
        <div className="mt-4 flex justify-center">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-semibold bg-white/20 text-white border-white/30">
            {isRisk ? <AlertCircle size={13} /> : <CheckCircle size={13} />}
            {lang === "te" ? "ప్రమాద స్థాయి: " : "Risk: "}{prediction.riskLevel.toUpperCase()}
          </span>
        </div>
      </div>

      {/* ── Body ─────────────────────────────────────────────────────── */}
      <div className="p-6 md:p-8 space-y-6">

        {/* Vital Alerts */}
        {prediction.alerts && (
          <motion.div variants={v} transition={{ delay: 0.1 }}>
            <Section
              icon={<Activity size={14} />}
              title={lang === "te" ? "వైటల్స్ అలర్ట్ సారాంశం" : "Vital Alert Summary"}
              color="text-muted-foreground"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <AlertBadge label="❤️ Heart Rate" status={prediction.alerts.heartRate} />
                <AlertBadge label="🫁 SpO2 Level" status={prediction.alerts.spo2} />
                <AlertBadge label="🩺 Blood Pressure" status={prediction.alerts.bloodPressure} />
                <AlertBadge label="🌡️ Temperature" status={prediction.alerts.temperature} />
              </div>
            </Section>
          </motion.div>
        )}

        {/* Condition + Advice */}
        <div className="grid md:grid-cols-2 gap-4">
          <motion.div variants={v} transition={{ delay: 0.15 }}
            className="bg-secondary/40 rounded-2xl p-5 border border-border/50">
            <div className="flex items-center mb-3">
              <Heart className="text-primary mr-2" size={18} />
              <h3 className="font-bold text-foreground text-sm">
                {lang === "te" ? "అంచనా వేసిన స్థితి" : "Predicted Condition"}
              </h3>
            </div>
            <p className="text-base font-semibold text-foreground/90">{displayName}</p>
            <span className={`mt-2 inline-flex text-xs font-semibold px-2 py-0.5 rounded-full border ${RISK_BADGE[prediction.riskLevel]}`}>
              {prediction.riskLevel} risk
            </span>
          </motion.div>

          <motion.div variants={v} transition={{ delay: 0.2 }}
            className="bg-secondary/40 rounded-2xl p-5 border border-border/50">
            <div className="flex items-center mb-3">
              <ClipboardList className="text-primary mr-2" size={18} />
              <h3 className="font-bold text-foreground text-sm">
                {lang === "te" ? "వైద్య సలహా" : "Medical Advice"}
              </h3>
            </div>
            <p className="text-sm leading-relaxed text-foreground/80">{prediction.advice}</p>
          </motion.div>
        </div>

        {/* Online Appointment Booking */}
        {prediction.specialists && prediction.specialists.length > 0 && (
          <motion.div variants={v} transition={{ delay: 0.22 }}>
            <AppointmentBooking
              specialists={prediction.specialists}
              lang={lang}
              patientDisease={prediction.disease}
            />
          </motion.div>
        )}

        {/* Government Subsidy Schemes */}
        <motion.div variants={v} transition={{ delay: 0.24 }}>
          <SubsidySchemes lang={lang} />
        </motion.div>

        {/* Home Remedies — bilingual */}
        {homeRemedies.length > 0 && (
          <motion.div variants={v} transition={{ delay: 0.25 }}>
            <Section
              icon={<Leaf size={14} />}
              title={lang === "te" ? "ఇంటి చికిత్సలు" : "Home Remedies"}
              color="text-emerald-700"
            >
              <ul className="space-y-2">
                {homeRemedies.map((r, i) => (
                  <li key={i} className="flex items-start bg-emerald-50 border border-emerald-200 p-3.5 rounded-xl text-sm text-emerald-900 leading-relaxed">
                    <span className="text-emerald-500 mr-2 mt-0.5 flex-shrink-0">🌿</span>
                    {r}
                  </li>
                ))}
              </ul>
            </Section>
          </motion.div>
        )}

        {/* Precautions — bilingual */}
        {precautions.length > 0 && (
          <motion.div variants={v} transition={{ delay: 0.3 }}>
            <Section
              icon={<ShieldCheck size={14} />}
              title={lang === "te" ? "జాగ్రత్తలు" : "Precautions"}
              color="text-orange-700"
            >
              <ul className="space-y-2">
                {precautions.map((p, i) => (
                  <li key={i} className="flex items-start bg-orange-50 border border-orange-200 p-3.5 rounded-xl text-sm text-orange-900 leading-relaxed">
                    <span className="text-orange-500 mr-2 mt-0.5 flex-shrink-0">⚠️</span>
                    {p}
                  </li>
                ))}
              </ul>
            </Section>
          </motion.div>
        )}

        {/* Specialists */}
        {prediction.specialists?.length > 0 && (
          <motion.div variants={v} transition={{ delay: 0.35 }}>
            <Section
              icon={<Phone size={14} />}
              title={lang === "te" ? "సంప్రదించవలసిన నిపుణులు" : "Recommended Specialists"}
              color="text-blue-700"
            >
              <div className="space-y-3">
                {prediction.specialists.map((s: Specialist, i: number) => (
                  <div key={i} className={`rounded-2xl p-4 border ${SPECIALIST_COLORS[i % SPECIALIST_COLORS.length]}`}>
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm flex-shrink-0">
                          <User size={15} className="text-blue-600" />
                        </div>
                        <div>
                          <p className="font-bold text-sm text-foreground">{s.name}</p>
                          <p className="text-xs text-muted-foreground font-medium">{s.type}</p>
                        </div>
                      </div>
                      <a href={`tel:${s.phone}`}
                        className="flex items-center gap-1.5 text-xs font-semibold text-blue-700 bg-blue-100 hover:bg-blue-200 px-3 py-1.5 rounded-full transition-colors flex-shrink-0">
                        <Phone size={11} /> {s.phone}
                      </a>
                    </div>
                    <div className="mt-2 ml-10 space-y-0.5">
                      <p className="text-xs text-muted-foreground">🏥 {s.hospital}</p>
                      <p className="text-xs text-muted-foreground">🕐 {s.available}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Section>
          </motion.div>
        )}

        {/* Detailed Findings */}
        <motion.div variants={v} transition={{ delay: 0.4 }}>
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 px-1">
            {lang === "te" ? "వివరణాత్మక ఫలితాలు" : "Detailed Findings"}
          </h3>
          <ul className="space-y-2">
            {prediction.details.map((detail, idx) => (
              <li key={idx}
                className="flex items-start bg-background p-3.5 rounded-xl border border-border/60 text-sm text-foreground/80 leading-relaxed">
                <div className={`w-2 h-2 rounded-full mt-1.5 mr-3 flex-shrink-0
                  ${detail.includes("ABNORMAL") ? "bg-red-500" : "bg-teal-500"}`} />
                {detail}
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Reset */}
        <motion.button
          variants={v} transition={{ delay: 0.45 }}
          whileHover={{ y: -2 }} whileTap={{ y: 0 }}
          onClick={onReset}
          className="w-full py-4 rounded-xl font-bold text-white bg-foreground hover:bg-foreground/90 transition-all shadow-lg flex items-center justify-center group"
        >
          <RefreshCw size={18} className="mr-2 group-hover:rotate-180 transition-transform duration-500" />
          {resetLabel}
        </motion.button>
      </div>
    </motion.div>
  );
}
