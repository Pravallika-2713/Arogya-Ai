import { Home, Stethoscope, User } from "lucide-react";
import { useLocation } from "wouter";
import { useAppContext } from "@/context/app-context";

const TABS = [
  { path: "/",        icon: Home,         label: { en: "Home",  te: "హోమ్" } },
  { path: "/chat",   icon: Stethoscope,  label: { en: "Check", te: "పరీక్ష" } },
  { path: "/profile", icon: User,        label: { en: "Profile", te: "ప్రొఫైల్" } },
];

export function BottomNav() {
  const [location, navigate] = useLocation();
  const { lang } = useAppContext();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-t border-border/40 shadow-lg">
      <div className="max-w-lg mx-auto flex">
        {TABS.map(({ path, icon: Icon, label }) => {
          const active = location === path;
          return (
            <button
              key={path}
              onClick={() => navigate(path)}
              className={`flex-1 flex flex-col items-center justify-center py-2.5 gap-0.5 transition-all ${
                active
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${active ? "bg-primary/10" : ""}`}>
                <Icon size={20} strokeWidth={active ? 2.5 : 1.8} />
              </div>
              <span className={`text-[10px] font-semibold tracking-wide ${active ? "text-primary" : ""}`}>
                {label[lang]}
              </span>
              {active && (
                <div className="absolute bottom-0 w-8 h-0.5 bg-primary rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
