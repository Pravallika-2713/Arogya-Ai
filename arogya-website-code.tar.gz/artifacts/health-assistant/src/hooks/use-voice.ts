/**
 * Voice hook — provides speech-to-text (microphone) and text-to-speech.
 * Uses the Web Speech API (built into all modern browsers — no external dependency).
 *
 * Supported languages: en-IN (English India), te-IN (Telugu)
 */

import { useState, useCallback, useRef } from "react";

// Lightweight type for the Web Speech Recognition API
type SpeechResultEvent = { results: { [idx: number]: { [idx: number]: { transcript: string } } } };
type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onresult: ((e: SpeechResultEvent) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
};
type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

export type VoiceLang = "en" | "te";

const LANG_CODES: Record<VoiceLang, string> = {
  en: "en-IN",
  te: "te-IN",
};

const TTS_VOICES_PREFERRED: Record<VoiceLang, string[]> = {
  en: ["Google UK English Female", "Microsoft Zira", "en-IN"],
  te: ["Google Telugu", "te-IN"],
};

function getBestVoice(lang: VoiceLang): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !window.speechSynthesis) return null;
  const voices = window.speechSynthesis.getVoices();
  const preferred = TTS_VOICES_PREFERRED[lang];
  for (const name of preferred) {
    const v = voices.find(
      (v) => v.name.includes(name) || v.lang.startsWith(name)
    );
    if (v) return v;
  }
  // Fallback: any voice matching the language code
  return voices.find((v) => v.lang.startsWith(LANG_CODES[lang].slice(0, 2))) ?? null;
}

export function useVoice(lang: VoiceLang) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  // ── Text-to-speech ────────────────────────────────────────────────────────
  const speak = useCallback(
    (text: string, onEnd?: () => void) => {
      if (!window.speechSynthesis) return;

      // Strip markdown bold/italic symbols before speaking
      const clean = text
        .replace(/\*\*(.*?)\*\*/g, "$1")
        .replace(/\*(.*?)\*/g, "$1")
        .replace(/━+/g, "")
        .replace(/_(.+?)_/g, "$1")
        .replace(/#+ /g, "")
        .trim();

      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(clean);
      utter.lang = LANG_CODES[lang];
      utter.rate = 0.95;
      utter.pitch = 1.05;

      // Try to use a matching voice; if not available yet, let the browser pick
      const loadVoices = () => {
        const voice = getBestVoice(lang);
        if (voice) utter.voice = voice;
      };
      loadVoices();
      if (window.speechSynthesis.getVoices().length === 0) {
        window.speechSynthesis.addEventListener("voiceschanged", loadVoices, { once: true });
      }

      utter.onstart = () => setIsSpeaking(true);
      utter.onend = () => { setIsSpeaking(false); onEnd?.(); };
      utter.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utter);
    },
    [lang]
  );

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
  }, []);

  // ── Speech-to-text ────────────────────────────────────────────────────────
  const startListening = useCallback(
    (onResult: (text: string) => void, onError?: (err: string) => void) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const w = window as any;
      const Ctor: SpeechRecognitionCtor | undefined =
        (w.SpeechRecognition ?? w.webkitSpeechRecognition) as SpeechRecognitionCtor | undefined;

      if (!Ctor) {
        onError?.("Speech recognition is not supported in this browser. Please use Google Chrome.");
        return;
      }

      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }

      const rec: SpeechRecognitionLike = new Ctor();
      rec.lang = LANG_CODES[lang];
      rec.continuous = false;
      rec.interimResults = false;
      rec.maxAlternatives = 1;

      rec.onstart = () => setIsListening(true);
      rec.onresult = (e: SpeechResultEvent) => {
        const transcript = e.results[0][0].transcript;
        setIsListening(false);
        onResult(transcript);
      };
      rec.onerror = (e: { error: string }) => {
        setIsListening(false);
        onError?.(e.error);
      };
      rec.onend = () => setIsListening(false);

      recognitionRef.current = rec;
      rec.start();
    },
    [lang]
  );

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);

  return { speak, stopSpeaking, isSpeaking, startListening, stopListening, isListening };
}
