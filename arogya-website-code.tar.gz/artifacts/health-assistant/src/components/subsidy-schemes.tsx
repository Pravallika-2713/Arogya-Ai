import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, ChevronUp, IndianRupee, Phone, ExternalLink, CheckCircle2 } from "lucide-react";
import type { VoiceLang } from "@/hooks/use-voice";

interface SubsidySchemesProps {
  lang: VoiceLang;
}

const L: Record<VoiceLang, { title: string; subtitle: string; eligibility: string; coverage: string; apply: string; call: string; website: string; note: string }> = {
  en: {
    title: "Government Health Subsidies", subtitle: "Free & subsidized healthcare schemes you may qualify for",
    eligibility: "Eligibility", coverage: "Coverage", apply: "Apply Now", call: "Call Helpline",
    website: "Visit Website", note: "💡 Tip: Keep your Aadhaar card and ration card ready when applying.",
  },
  te: {
    title: "ప్రభుత్వ ఆరోగ్య సహాయం", subtitle: "మీకు అర్హత ఉండే ఉచిత & రాయితీ ఆరోగ్య పథకాలు",
    eligibility: "అర్హత", coverage: "సహాయం", apply: "దరఖాస్తు చేయండి", call: "హెల్ప్‌లైన్",
    website: "వెబ్‌సైట్", note: "💡 చిట్కా: దరఖాస్తు చేసేటప్పుడు ఆధార్ కార్డ్ మరియు రేషన్ కార్డ్ సిద్ధంగా ఉంచుకోండి.",
  },
};

interface Scheme {
  icon: string;
  name: Record<VoiceLang, string>;
  tag: Record<VoiceLang, string>;
  coverage: Record<VoiceLang, string>;
  eligibility: Record<VoiceLang, string[]>;
  helpline: string;
  website: string;
  color: string;
  tagColor: string;
}

const SCHEMES: Scheme[] = [
  {
    icon: "🇮🇳",
    name: { en: "Ayushman Bharat PM-JAY", te: "ఆయుష్మాన్ భారత్ PM-JAY" },
    tag: { en: "National Scheme", te: "జాతీయ పథకం" },
    coverage: { en: "₹5 lakh per family per year — covers hospitalisation, surgery & critical illness", te: "కుటుంబానికి సంవత్సరానికి ₹5 లక్షలు — ఆసుపత్రి, శస్త్రచికిత్స & తీవ్ర జబ్బులు" },
    eligibility: {
      en: ["Families listed in SECC 2011 database", "BPL card holders", "No annual income limit for eligible rural families"],
      te: ["SECC 2011 జాబితాలోని కుటుంబాలు", "BPL కార్డ్ హోల్డర్లు", "అర్హత పొందిన గ్రామీణ కుటుంబాలకు ఆదాయ పరిమితి లేదు"],
    },
    helpline: "14555",
    website: "https://pmjay.gov.in",
    color: "border-orange-200 bg-orange-50",
    tagColor: "bg-orange-100 text-orange-700",
  },
  {
    icon: "🌺",
    name: { en: "Aarogyasri (Telangana)", te: "ఆరోగ్యశ్రీ (తెలంగాణ)" },
    tag: { en: "Telangana State", te: "తెలంగాణ రాష్ట్రం" },
    coverage: { en: "₹5 lakh per family per year — 3,000+ procedures across 400+ empanelled hospitals", te: "కుటుంబానికి ₹5 లక్షలు — 400+ నెట్‌వర్క్ ఆసుపత్రులలో 3,000+ చికిత్సలు" },
    eligibility: {
      en: ["White ration card / Below Poverty Line families", "Telangana state residents", "Income below ₹5 lakh per year"],
      te: ["తెల్ల రేషన్ కార్డ్ / BPL కుటుంబాలు", "తెలంగాణ రాష్ట్ర నివాసులు", "వార్షిక ఆదాయం ₹5 లక్షల కంటే తక్కువ"],
    },
    helpline: "104",
    website: "https://www.aarogyasri.telangana.gov.in",
    color: "border-pink-200 bg-pink-50",
    tagColor: "bg-pink-100 text-pink-700",
  },
  {
    icon: "🏛️",
    name: { en: "YSR Aarogyasri (Andhra Pradesh)", te: "YSR ఆరోగ్యశ్రీ (ఆంధ్రప్రదేశ్)" },
    tag: { en: "Andhra Pradesh", te: "ఆంధ్రప్రదేశ్" },
    coverage: { en: "Up to ₹25 lakh per family — covers 2,500+ procedures including heart, kidney & cancer care", te: "కుటుంబానికి ₹25 లక్షల వరకు — గుండె, మూత్రపిండాలు & క్యాన్సర్ చికిత్సలతో సహా 2,500+ ప్రక్రియలు" },
    eligibility: {
      en: ["White / yellow ration card holders", "Andhra Pradesh state residents", "All Below Poverty Line families"],
      te: ["తెల్ల / పసుపు రేషన్ కార్డ్ హోల్డర్లు", "ఆంధ్రప్రదేశ్ రాష్ట్ర నివాసులు", "అన్ని BPL కుటుంబాలు"],
    },
    helpline: "104",
    website: "https://ysrarogyasri.ap.gov.in",
    color: "border-yellow-200 bg-yellow-50",
    tagColor: "bg-yellow-100 text-yellow-700",
  },
  {
    icon: "🏢",
    name: { en: "ESI Scheme (ESIC)", te: "ESI పథకం (ESIC)" },
    tag: { en: "For Employees", te: "ఉద్యోగుల కోసం" },
    coverage: { en: "Full medical coverage for employee & family — including specialist care, medicines & hospitalisation", te: "ఉద్యోగి & కుటుంబానికి పూర్తి వైద్య సేవలు — నిపుణుల సేవలు, మందులు & ఆసుపత్రి" },
    eligibility: {
      en: ["Employees earning up to ₹21,000/month", "Registered in ESIC-covered establishments", "Contributions deducted from salary"],
      te: ["నెలకు ₹21,000 వరకు సంపాదించే ఉద్యోగులు", "ESIC పరిధిలో నమోదైన సంస్థల్లో పనిచేసేవారు"],
    },
    helpline: "1800-11-2526",
    website: "https://esic.gov.in",
    color: "border-blue-200 bg-blue-50",
    tagColor: "bg-blue-100 text-blue-700",
  },
  {
    icon: "💚",
    name: { en: "Pradhan Mantri Jan Aushadhi Yojana", te: "జన ఔషధి పథకం" },
    tag: { en: "Medicines @ 50–90% Off", te: "మందులు 50–90% తక్కువ ధరకు" },
    coverage: { en: "Generic medicines at 50–90% lower cost at 10,000+ Jan Aushadhi Kendras across India", te: "భారతదేశంలో 10,000+ జన ఔషధి కేంద్రాల ద్వారా 50–90% తక్కువ ధరకు జెనెరిక్ మందులు" },
    eligibility: {
      en: ["Open to all Indian citizens", "No registration required", "Just visit the nearest Kendra with prescription"],
      te: ["అన్ని భారత పౌరులకు అందుబాటు", "నమోదు అవసరం లేదు", "సమీప కేంద్రానికి వెళ్ళండి"],
    },
    helpline: "1800-11-8010",
    website: "https://janaushadhi.gov.in",
    color: "border-green-200 bg-green-50",
    tagColor: "bg-green-100 text-green-700",
  },
];

function SchemeCard({ scheme, lang }: { scheme: Scheme; lang: VoiceLang }) {
  const [expanded, setExpanded] = useState(false);
  const t = L[lang];
  return (
    <div className={`rounded-2xl border ${scheme.color} overflow-hidden`}>
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center justify-between p-4 hover:brightness-95 transition-all text-left"
      >
        <div className="flex items-start gap-3">
          <span className="text-2xl">{scheme.icon}</span>
          <div>
            <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mb-1 ${scheme.tagColor}`}>
              {scheme.tag[lang]}
            </span>
            <p className="font-bold text-sm text-foreground">{scheme.name[lang]}</p>
          </div>
        </div>
        {expanded ? <ChevronUp size={16} className="text-muted-foreground flex-shrink-0" /> : <ChevronDown size={16} className="text-muted-foreground flex-shrink-0" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-3 border-t border-black/5">
              {/* Coverage */}
              <div className="mt-3">
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1">
                  <IndianRupee size={10} className="inline mr-1" />{t.coverage}
                </p>
                <p className="text-sm text-foreground/80 leading-relaxed">{scheme.coverage[lang]}</p>
              </div>

              {/* Eligibility */}
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">
                  <CheckCircle2 size={10} className="inline mr-1" />{t.eligibility}
                </p>
                <ul className="space-y-1">
                  {scheme.eligibility[lang].map((e, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-foreground/70">
                      <span className="text-emerald-500 mt-0.5 flex-shrink-0">✓</span>
                      {e}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <a
                  href={`tel:${scheme.helpline}`}
                  onClick={(e) => e.stopPropagation()}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl border border-current text-xs font-bold text-blue-700 bg-blue-100 hover:bg-blue-200 transition-colors"
                >
                  <Phone size={12} /> {t.call}: {scheme.helpline}
                </a>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); window.open(scheme.website, "_blank", "noopener,noreferrer"); }}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-foreground text-white text-xs font-bold hover:bg-foreground/90 transition-colors"
                >
                  <ExternalLink size={12} /> {t.apply} ↗
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function SubsidySchemes({ lang }: SubsidySchemesProps) {
  const [open, setOpen] = useState(false);
  const t = L[lang];

  return (
    <div className="rounded-2xl border border-violet-200 bg-violet-50 overflow-hidden">
      {/* Section header */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between p-4 hover:bg-violet-100 transition-colors"
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-violet-600 flex items-center justify-center flex-shrink-0">
            <IndianRupee size={16} className="text-white" />
          </div>
          <div className="text-left">
            <p className="font-bold text-sm text-violet-900">{t.title}</p>
            <p className="text-xs text-violet-600">{t.subtitle}</p>
          </div>
        </div>
        {open ? <ChevronUp size={18} className="text-violet-600" /> : <ChevronDown size={18} className="text-violet-600" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-2 border-t border-violet-200">
              <p className="text-xs text-violet-700 font-medium pt-3 px-1 pb-1">{t.note}</p>
              {SCHEMES.map((s, i) => (
                <SchemeCard key={i} scheme={s} lang={lang} />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
