export type Disease = "Healthy" | "Asthma" | "Heart Disease" | "Hypertension" | "Diabetes Mellitus";
export type Lang = "en" | "te";

interface RemedySet {
  homeRemedies: string[];
  precautions: string[];
}

export const REMEDIES: Record<Disease, Record<Lang, RemedySet>> = {
  "Heart Disease": {
    en: {
      homeRemedies: [
        "Consume garlic daily — reduces cholesterol and blood pressure",
        "Drink pomegranate juice — antioxidants that protect the heart",
        "Add omega-3 rich foods: walnuts, flaxseeds, and fish",
        "Turmeric milk (haldi doodh) — anti-inflammatory and heart-protective",
        "Practice deep breathing (Pranayama) for 10–15 minutes daily",
      ],
      precautions: [
        "Avoid smoking and alcohol completely",
        "Limit salt intake to less than 5g per day",
        "Avoid heavy lifting and sudden intense exercise",
        "Monitor heart rate and blood pressure daily",
        "Take prescribed medications without skipping any dose",
        "Maintain a healthy weight — even 5 kg reduction helps greatly",
      ],
    },
    te: {
      homeRemedies: [
        "వెల్లుల్లి రోజూ తినండి — కొలెస్ట్రాల్ మరియు రక్తపోటు తగ్గిస్తుంది",
        "దానిమ్మపండు రసం తాగండి — యాంటీఆక్సిడెంట్లు గుండెను రక్షిస్తాయి",
        "ఓమేగా-3 అధికంగా ఉన్న ఆహారం: వాల్‌నట్లు, అవిసె గింజలు, చేప తినండి",
        "పసుపు పాలు — యాంటీ-ఇన్ఫ్లమేటరీ మరియు గుండెను రక్షిస్తుంది",
        "రోజూ 10–15 నిమిషాలు ప్రాణాయామం అభ్యసించండి",
      ],
      precautions: [
        "ధూమపానం మరియు మద్యపానం పూర్తిగా మానుకోండి",
        "రోజువారీ ఉప్పు 5 గ్రాముల కంటే తక్కువగా ఉంచండి",
        "అధిక బరువు మోయడం మరియు అకస్మాత్తుగా తీవ్రమైన వ్యాయామం మానుకోండి",
        "రోజూ హృదయ స్పందన మరియు రక్తపోటు పర్యవేక్షించండి",
        "వైద్యుడు సూచించిన మందులు ఒక్క మోతాదు కూడా తప్పకుండా వేసుకోండి",
        "ఆరోగ్యకరమైన బరువు నిర్వహించండి — 5 కి.గ్రా. తగ్గింపు కూడా చాలా సహాయపడుతుంది",
      ],
    },
  },

  "Asthma": {
    en: {
      homeRemedies: [
        "Steam inhalation with eucalyptus oil — opens airways",
        "Ginger tea with honey — natural bronchodilator and anti-inflammatory",
        "Turmeric in warm water or milk — reduces airway inflammation",
        "Breathe through pursed lips during an attack to slow breathing",
        "Keep indoor plants like aloe vera — improves air quality",
      ],
      precautions: [
        "Avoid dust, smoke, strong perfumes, and allergens",
        "Always carry your inhaler and never skip maintenance medication",
        "Keep windows closed during high-pollen seasons",
        "Wear a mask in dusty or polluted environments",
        "Exercise only in clean air on non-polluted days",
        "Identify and avoid your personal triggers",
      ],
    },
    te: {
      homeRemedies: [
        "యూకలిప్టస్ నూనెతో ఆవిరి పీల్చండి — శ్వాసనాళాలు తెరుచుకుంటాయి",
        "అల్లం చాయ్ తేనెతో — సహజ బ్రాంకోడైలేటర్ మరియు వాపు తగ్గిస్తుంది",
        "వెచ్చని నీటిలో లేదా పాలలో పసుపు — శ్వాసనాళ వాపు తగ్గిస్తుంది",
        "దాడి సమయంలో నోటి ద్వారా మెల్లగా శ్వాస తీసుకోండి",
        "అలోవెరా వంటి ఇంటి మొక్కలు పెంచండి — గాలి నాణ్యత మెరుగుపడుతుంది",
      ],
      precautions: [
        "దుమ్ము, పొగ, తీవ్రమైన సుగంధాలు మరియు అలెర్జెన్‌లను నివారించండి",
        "ఇన్హేలర్ ఎల్లప్పుడూ వెంట ఉంచుకోండి, నిర్వహణ మందు మానవద్దు",
        "అధిక పుప్పొడి సీజన్లలో కిటికీలు మూసి ఉంచండి",
        "దుమ్ము లేదా కాలుష్య వాతావరణంలో మాస్క్ ధరించండి",
        "స్వచ్ఛమైన గాలిలో మాత్రమే వ్యాయామం చేయండి",
        "మీ వ్యక్తిగత ట్రిగ్గర్‌లను గుర్తించి నివారించండి",
      ],
    },
  },

  "Hypertension": {
    en: {
      homeRemedies: [
        "Eat a banana daily — high potassium helps lower blood pressure",
        "Hibiscus tea (2 cups/day) — clinically shown to reduce BP",
        "Reduce sodium: use lemon juice and herbs instead of extra salt",
        "Dark chocolate (70%+ cocoa) in small amounts — contains flavanols",
        "Meditation and yoga (15–20 min/day) significantly lower stress-induced BP",
      ],
      precautions: [
        "Monitor blood pressure at the same time every day",
        "Limit sodium to less than 2300 mg per day",
        "Avoid alcohol and quit smoking",
        "Maintain body weight in normal BMI range (18.5–24.9)",
        "Follow the DASH diet: fruits, vegetables, whole grains, low-fat dairy",
        "Avoid caffeine within 30 minutes before BP reading",
      ],
    },
    te: {
      homeRemedies: [
        "రోజూ అరటిపండు తినండి — పొటాషియం అధికంగా ఉంటుంది, BP తగ్గిస్తుంది",
        "గోంగూర/హిబిస్కస్ చాయ్ (రోజుకు 2 కప్పులు) — రక్తపోటు తగ్గిస్తుందని నిరూపించబడింది",
        "ఉప్పు తగ్గించండి: బదులుగా నిమ్మకాయ రసం, మసాలాలు వాడండి",
        "డార్క్ చాకొలెట్ (70%+ కోకో) చిన్న మొత్తంలో — ఫ్లావనాల్స్ కలిగి ఉంటుంది",
        "ధ్యానం మరియు యోగా (15–20 నిమి/రోజు) రక్తపోటు గణనీయంగా తగ్గిస్తాయి",
      ],
      precautions: [
        "రోజూ ఒకే సమయంలో రక్తపోటు కొలవండి",
        "రోజువారీ సోడియం 2300 mg కంటే తక్కువగా ఉంచండి",
        "మద్యపానం మానుకోండి మరియు ధూమపానం మానేయండి",
        "BMI 18.5–24.9 పరిధిలో శరీర బరువు నిర్వహించండి",
        "DASH డైట్ పాటించండి: పండ్లు, కూరగాయలు, ధాన్యాలు, తక్కువ కొవ్వు పాల ఉత్పత్తులు",
        "BP చదివే ముందు 30 నిమిషాల్లో కాఫీ తాగవద్దు",
      ],
    },
  },

  "Diabetes Mellitus": {
    en: {
      homeRemedies: [
        "Bitter gourd (karela) juice — natural insulin-like compound lowers blood sugar",
        "Fenugreek seeds soaked overnight: drink the water on an empty stomach",
        "Cinnamon (½ tsp/day) in warm water — improves insulin sensitivity",
        "Amla (Indian gooseberry) juice with turmeric — powerful antidiabetic combination",
        "Regular walks of 30 minutes after meals reduce post-meal glucose spikes",
      ],
      precautions: [
        "Check blood sugar levels regularly as advised by your doctor",
        "Avoid sugary foods, white rice, white bread, and processed snacks",
        "Eat small, frequent meals every 3–4 hours to maintain stable glucose",
        "Never skip meals, especially if on insulin or glucose-lowering medication",
        "Inspect your feet daily for cuts or sores",
        "Stay well hydrated — drink at least 2–3 litres of water daily",
      ],
    },
    te: {
      homeRemedies: [
        "కారెళ్ళ రసం — సహజ ఇన్సులిన్ వంటి సమ్మేళనం రక్తంలో చక్కెర తగ్గిస్తుంది",
        "రాత్రంతా నానబెట్టిన మేతి గింజలు: ఉదయం ఆ నీరు ఖాళీ కడుపుతో తాగండి",
        "వెచ్చని నీటిలో దాల్చినచెక్క (½ స్పూన్/రోజు) — ఇన్సులిన్ సంవేదనశీలత మెరుగుపడుతుంది",
        "ఉసిరికాయ రసం పసుపుతో — శక్తివంతమైన యాంటీడయాబెటిక్ కలయిక",
        "తినిన తర్వాత 30 నిమిషాల నడక — భోజనం తర్వాత గ్లూకోజ్ స్పైక్ తగ్గుతుంది",
      ],
      precautions: [
        "వైద్యుడు సూచించినట్లు నిత్యం రక్తంలో చక్కెర స్థాయిలు తనిఖీ చేయండి",
        "చక్కెర పదార్థాలు, తెల్ల బియ్యం, తెల్ల రొట్టె మరియు ప్రాసెస్ చేసిన స్నాక్స్ మానుకోండి",
        "ప్రతి 3–4 గంటలకు చిన్న చిన్న భోజనాలు చేసి గ్లూకోజ్ స్థిరంగా ఉంచుకోండి",
        "భోజనం మానకండి, ముఖ్యంగా ఇన్సులిన్ లేదా మందులు వేసుకుంటే",
        "రోజూ పాదాలను గాయాల కోసం పరిశీలించండి",
        "రోజూ కనీసం 2–3 లీటర్ల నీరు తాగండి",
      ],
    },
  },

  "Healthy": {
    en: {
      homeRemedies: [
        "Drink 2–3 litres of water daily",
        "Include fresh fruits and vegetables in every meal",
        "Neem or tulsi leaves in warm water every morning — boosts immunity",
        "A handful of mixed nuts daily — healthy fats and micronutrients",
        "Green tea (1–2 cups/day) — antioxidant-rich and metabolism-boosting",
      ],
      precautions: [
        "Maintain 30 minutes of physical activity, 5 days a week",
        "Get 7–8 hours of quality sleep every night",
        "Have annual health checkups even when feeling well",
        "Manage stress through hobbies, yoga, or mindfulness",
        "Maintain a balanced diet with limited processed food and sugar",
        "Avoid tobacco and limit alcohol consumption",
      ],
    },
    te: {
      homeRemedies: [
        "రోజూ 2–3 లీటర్ల నీరు తాగండి",
        "ప్రతి భోజనంలో తాజా పండ్లు మరియు కూరగాయలు తీసుకోండి",
        "నేర వేప లేదా తులసి ఆకులు వెచ్చని నీటిలో ప్రతి ఉదయం — రోగనిరోధక శక్తి పెరుగుతుంది",
        "రోజూ ఒక గుప్పెడు మిక్స్ నట్స్ — ఆరోగ్యకరమైన కొవ్వులు మరియు మైక్రోన్యూట్రియెంట్లు",
        "గ్రీన్ టీ (రోజుకు 1–2 కప్పులు) — యాంటీఆక్సిడెంట్ అధికంగా ఉంటుంది",
      ],
      precautions: [
        "వారానికి 5 రోజులు 30 నిమిషాల శారీరక చర్య చేయండి",
        "ప్రతి రాత్రి 7–8 గంటలు నిద్రపోండి",
        "ఆరోగ్యంగా అనిపించినా వార్షిక ఆరోగ్య పరీక్షలు చేయించుకోండి",
        "అభిరుచులు, యోగా లేదా మెడిటేషన్ ద్వారా ఒత్తిడి నిర్వహించండి",
        "ప్రాసెస్ చేసిన ఆహారం మరియు చక్కెర తక్కువగా తింటూ సమతుల్య ఆహారం తీసుకోండి",
        "పొగతాగడం మానుకోండి మరియు మద్యపానం పరిమితం చేయండి",
      ],
    },
  },
};
