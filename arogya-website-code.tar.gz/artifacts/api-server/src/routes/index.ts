import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import chatbotRouter from "./chatbot.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(chatbotRouter);

export default router;
