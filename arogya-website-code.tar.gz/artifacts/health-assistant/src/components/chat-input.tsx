import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send, HeartPulse, Wind, Thermometer, ArrowUp, ArrowDown,
  Mic, MicOff, Volume2, VolumeX, Wifi, Activity, Calendar
} from "lucide-react";
import type { ChatResponseNextStep } from "@workspace/api-client-react";
import type { VoiceLang } from "@/hooks/use-voice";

interface ChatInputProps {
  nextStep: ChatResponseNextStep;
  isTyping: boolean;
  onSendMessage: (text: string) => void;
  lang: VoiceLang;
  onLangToggle: () => void;
  isListening: boolean;
  isSpeaking: boolean;
  onMicClick: () => void;
  onTtsToggle: () => void;
  ttsEnabled: boolean;
}

// ── Device simulation ranges ───────────────────────────────────────────────
const DEVICE_SIM: Record<string, { min: number; max: number; decimal: number }> = {
  heartRate:   { min: 62,   max: 118,  decimal: 0 },
  spo2:        { min: 93,   max: 99,   decimal: 0 },
  systolicBP:  { min: 110,  max: 158,  decimal: 0 },
  diastolicBP: { min: 70,   max: 97,   decimal: 0 },
  temperature: { min: 36.2, max: 38.2, decimal: 1 },
};

function simValue(step: string): number {
  const r = DEVICE_SIM[step];
  if (!r) return 0;
  const v = r.min + Math.random() * (r.max - r.min);
  const factor = Math.pow(10, r.decimal);
  return Math.round(v * factor) / factor;
}

// ── Label translations ─────────────────────────────────────────────────────
const LABELS: Record<VoiceLang, {
  yes: string; no: string; fallPrompt: string;
  breathPrompt: string; chestPrompt: string; familyPrompt: string;
  daysPrompt: string; daysPlaceholder: string;
  typing: string; langBtn: string; voiceOn: string; voiceOff: string;
  listening: string; reading: string;
  deviceRead: string; deviceConnecting: string; deviceReading: string; deviceDone: string;
}> = {
  en: {
    yes: "Yes", no: "No",
    fallPrompt: "Have you experienced a recent fall or sudden loss of balance?",
    breathPrompt: "Do you experience shortness of breath or difficulty breathing?",
    chestPrompt: "Do you experience chest pain, pressure, or tightness?",
    familyPrompt: "Does your family have a history of heart disease, high BP, or diabetes?",
    daysPrompt: "How many days have you had these symptoms? (Enter 0 if sudden/today)",
    daysPlaceholder: "Number of days (e.g. 3, 0 for today)",
    typing: "Type your answer...", langBtn: "English",
    voiceOn: "Voice On", voiceOff: "Voice Off",
    listening: "🎙️ Listening... speak now",
    reading: "🔊 Reading aloud...",
    deviceRead: "📱 Read from Device",
    deviceConnecting: "🔌 Connecting to sensor...",
    deviceReading: "📊 Reading measurement...",
    deviceDone: "✅ Device reading captured!",
  },
  te: {
    yes: "అవును", no: "కాదు",
    fallPrompt: "ఇటీవల మీకు పడిపోవడం లేదా తూలుకొనే అనుభవం వచ్చిందా?",
    breathPrompt: "మీకు శ్వాస తీసుకోవడంలో ఇబ్బంది లేదా అల్పశ్వాస వస్తుందా?",
    chestPrompt: "మీకు ఛాతీ నొప్పి, ఒత్తిడి లేదా బిగుతుగా అనిపిస్తుందా?",
    familyPrompt: "మీ కుటుంబంలో గుండె జబ్బు, రక్తపోటు లేదా డయాబెటిస్ చరిత్ర ఉందా?",
    daysPrompt: "ఎన్ని రోజుల నుండి ఈ లక్షణాలు ఉన్నాయి? (ఈరోజే అయితే 0 నమోదు చేయండి)",
    daysPlaceholder: "రోజుల సంఖ్య (ఉదా: 3, ఈరోజు అయితే 0)",
    typing: "మీ సమాధానం టైప్ చేయండి...", langBtn: "తెలుగు",
    voiceOn: "శబ్దం ఆన్", voiceOff: "శబ్దం ఆఫ్",
    listening: "🎙️ వింటోంది... మాట్లాడండి",
    reading: "🔊 చదువుతోంది...",
    deviceRead: "📱 పరికరం నుండి చదవండి",
    deviceConnecting: "🔌 సెన్సార్‌కు కనెక్ట్ అవుతోంది...",
    deviceReading: "📊 కొలత చదువుతోంది...",
    deviceDone: "✅ పరికరం రీడింగ్ పూర్తైంది!",
  },
};

const VITAL_CONFIG: Record<string, { icon: React.ReactNode; color: string; step?: number; unit: string; ph: Record<VoiceLang, string> }> = {
  heartRate:   { icon: <HeartPulse size={22}/>, color: "text-rose-500",   unit: "BPM",  ph: { en: "Heart rate (e.g. 75)", te: "గుండె స్పందన (ఉదా: 75)" } },
  spo2:        { icon: <Wind size={22}/>,        color: "text-blue-500",   unit: "%",    ph: { en: "SpO2 level (e.g. 98)", te: "SpO2 స్థాయి (ఉదా: 98)" } },
  systolicBP:  { icon: <ArrowUp size={22}/>,     color: "text-purple-500", unit: "mmHg", ph: { en: "Systolic BP (e.g. 120)", te: "సిస్టోలిక్ BP (ఉదా: 120)" } },
  diastolicBP: { icon: <ArrowDown size={22}/>,   color: "text-indigo-500", unit: "mmHg", ph: { en: "Diastolic BP (e.g. 80)", te: "డయాస్టోలిక్ BP (ఉదా: 80)" } },
  temperature: { icon: <Thermometer size={22}/>, color: "text-orange-500", unit: "°C",  step: 0.1, ph: { en: "Temperature (e.g. 36.8)", te: "ఉష్ణోగ్రత (ఉదా: 36.8)" } },
};

// ── Device Vital Input (numeric + device-read button) ──────────────────────
type DevicePhase = "idle" | "connecting" | "reading" | "done";

function VitalInput({
  stepKey, lang, isTyping, onSubmit, onMicClick, isListening,
}: {
  stepKey: string; lang: VoiceLang; isTyping: boolean;
  onSubmit: (v: number) => void; onMicClick: () => void; isListening: boolean;
}) {
  const [val, setVal] = useState<number | "">("");
  const [phase, setPhase] = useState<DevicePhase>("idle");
  const L = LABELS[lang];
  const cfg = VITAL_CONFIG[stepKey];

  const handleDeviceRead = useCallback(() => {
    if (isTyping || phase !== "idle") return;
    setPhase("connecting");
    setTimeout(() => setPhase("reading"), 1200);
    setTimeout(() => {
      const v = simValue(stepKey);
      setVal(v);
      setPhase("done");
      setTimeout(() => setPhase("idle"), 2000);
    }, 2600);
  }, [isTyping, phase, stepKey]);

  const phaseLabel = phase === "connecting" ? L.deviceConnecting
    : phase === "reading" ? L.deviceReading
    : phase === "done" ? L.deviceDone
    : L.deviceRead;

  const phaseColor = phase === "done"
    ? "bg-emerald-50 border-emerald-400 text-emerald-700"
    : phase !== "idle"
    ? "bg-blue-50 border-blue-400 text-blue-700 animate-pulse"
    : "bg-slate-50 border-slate-300 text-slate-600 hover:bg-teal-50 hover:border-teal-400 hover:text-teal-700";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className="w-full bg-white rounded-2xl shadow-lg border border-border/60 overflow-hidden"
    >
      {/* Main input row */}
      <form
        onSubmit={(e) => { e.preventDefault(); if (val !== "") { onSubmit(Number(val)); setVal(""); setPhase("idle"); } }}
        className="flex items-center space-x-2 p-2"
      >
        <div className={`pl-3 ${cfg.color}`}>{cfg.icon}</div>
        <input
          type="number" step={cfg.step ?? 1}
          placeholder={cfg.ph[lang]}
          value={val}
          onChange={(e) => { setVal(e.target.value ? Number(e.target.value) : ""); setPhase("idle"); }}
          className="flex-1 bg-transparent py-3 px-2 focus:outline-none text-foreground text-lg placeholder:text-muted-foreground"
          disabled={isTyping} autoFocus
        />
        <span className="font-semibold text-muted-foreground pr-1">{cfg.unit}</span>
        <button type="button" onClick={onMicClick} disabled={isTyping}
          className={`p-2.5 rounded-xl transition-all ${isListening ? "bg-red-100 text-red-600 animate-pulse" : "bg-slate-100 text-slate-500 hover:bg-blue-50 hover:text-blue-600"} disabled:opacity-40`}>
          {isListening ? <MicOff size={18}/> : <Mic size={18}/>}
        </button>
        <button type="submit" disabled={isTyping || val === ""}
          className="bg-primary hover:bg-primary/90 text-white p-3 rounded-xl transition-all disabled:opacity-50">
          <Send size={18}/>
        </button>
      </form>

      {/* Device read button */}
      <div className="px-3 pb-3">
        <button
          type="button"
          onClick={handleDeviceRead}
          disabled={isTyping || phase === "connecting" || phase === "reading"}
          className={`w-full flex items-center justify-center gap-2 py-2 rounded-xl border text-xs font-semibold transition-all duration-300 ${phaseColor} disabled:cursor-not-allowed`}
        >
          {phase === "idle" && <Wifi size={14}/>}
          {phase !== "idle" && <Activity size={14} className={phase !== "done" ? "animate-spin" : ""}/>}
          {phaseLabel}
        </button>
        {val !== "" && phase === "done" && (
          <p className="text-xs text-center text-emerald-600 mt-1 font-medium">
            {lang === "te" ? `పరికరం చదివింది: ${val} ${cfg.unit}` : `Device reading: ${val} ${cfg.unit} — verify and submit`}
          </p>
        )}
      </div>
    </motion.div>
  );
}

// ── Yes/No buttons ─────────────────────────────────────────────────────────
function YesNoInput({ prompt, onSubmit, isTyping, lang }: {
  prompt: string; onSubmit: (yes: boolean) => void; isTyping: boolean; lang: VoiceLang;
}) {
  const L = LABELS[lang];
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      className="w-full bg-white p-4 rounded-2xl shadow-lg border border-border/60 space-y-3"
    >
      <p className="text-sm font-medium text-foreground/80 px-1">{prompt}</p>
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => onSubmit(true)} disabled={isTyping}
          className="py-3.5 rounded-xl font-bold bg-rose-500 text-white hover:bg-rose-600 transition-all disabled:opacity-50 shadow-md text-sm">
          ⚠️ {L.yes}
        </button>
        <button onClick={() => onSubmit(false)} disabled={isTyping}
          className="py-3.5 rounded-xl font-bold bg-emerald-500 text-white hover:bg-emerald-600 transition-all disabled:opacity-50 shadow-md text-sm">
          ✅ {L.no}
        </button>
      </div>
    </motion.div>
  );
}

// ── Days input ─────────────────────────────────────────────────────────────
function DaysInput({ lang, isTyping, onSubmit, onMicClick, isListening }: {
  lang: VoiceLang; isTyping: boolean;
  onSubmit: (v: number) => void; onMicClick: () => void; isListening: boolean;
}) {
  const [val, setVal] = useState<number | "">("");
  const L = LABELS[lang];
  return (
    <motion.form
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
      onSubmit={(e) => { e.preventDefault(); if (val !== "") { onSubmit(Number(val)); setVal(""); } }}
      className="flex items-center space-x-2 w-full bg-white p-2 rounded-2xl shadow-lg border border-border/60"
    >
      <div className="pl-3 text-amber-600"><Calendar size={22}/></div>
      <input
        type="number" min={0} step={1}
        placeholder={L.daysPlaceholder}
        value={val}
        onChange={(e) => setVal(e.target.value !== "" ? Number(e.target.value) : "")}
        className="flex-1 bg-transparent py-3 px-2 focus:outline-none text-foreground text-lg placeholder:text-muted-foreground"
        disabled={isTyping} autoFocus
      />
      <span className="font-semibold text-muted-foreground pr-1">{lang === "te" ? "రోజులు" : "days"}</span>
      <button type="button" onClick={onMicClick} disabled={isTyping}
        className={`p-2.5 rounded-xl transition-all ${isListening ? "bg-red-100 text-red-600 animate-pulse" : "bg-slate-100 text-slate-500 hover:bg-blue-50 hover:text-blue-600"} disabled:opacity-40`}>
        {isListening ? <MicOff size={18}/> : <Mic size={18}/>}
      </button>
      <button type="submit" disabled={isTyping || val === ""}
        className="bg-primary hover:bg-primary/90 text-white p-3 rounded-xl transition-all disabled:opacity-50">
        <Send size={18}/>
      </button>
    </motion.form>
  );
}

// ── Main ChatInput ─────────────────────────────────────────────────────────
export function ChatInput({
  nextStep, isTyping, onSendMessage, lang, onLangToggle,
  isListening, isSpeaking, onMicClick, onTtsToggle, ttsEnabled,
}: ChatInputProps) {
  const [text, setText] = useState("");
  const L = LABELS[lang];

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || isTyping) return;
    onSendMessage(text);
    setText("");
  };

  const renderInputArea = () => {
    if (nextStep === "predicting" || nextStep === "done") return null;

    // ── Yes/No question steps ──────────────────────────────────────────────
    const yesNoSteps: Partial<Record<ChatResponseNextStep, string>> = {
      fallDetection:  L.fallPrompt,
      breathShortness: L.breathPrompt,
      chestPain:      L.chestPrompt,
      familyHistory:  L.familyPrompt,
    };
    if (yesNoSteps[nextStep]) {
      return (
        <YesNoInput
          prompt={yesNoSteps[nextStep]!}
          onSubmit={(yes) => onSendMessage(yes ? "yes" : "no")}
          isTyping={isTyping}
          lang={lang}
        />
      );
    }

    // ── Symptom days number input ──────────────────────────────────────────
    if (nextStep === "symptomDays") {
      return (
        <DaysInput
          lang={lang} isTyping={isTyping}
          onSubmit={(v) => onSendMessage(`${v}`)}
          onMicClick={onMicClick} isListening={isListening}
        />
      );
    }

    // ── Device vital inputs ────────────────────────────────────────────────
    if (VITAL_CONFIG[nextStep]) {
      return (
        <VitalInput
          stepKey={nextStep}
          lang={lang} isTyping={isTyping}
          onSubmit={(v) => onSendMessage(`${v}`)}
          onMicClick={onMicClick} isListening={isListening}
        />
      );
    }

    // ── Default text input (greeting, name) ────────────────────────────────
    return (
      <motion.form
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        onSubmit={handleTextSubmit}
        className="flex items-center w-full bg-white p-2 rounded-2xl shadow-lg border border-border/60 gap-2"
      >
        <input
          type="text" placeholder={L.typing}
          value={text} onChange={(e) => setText(e.target.value)}
          className="flex-1 bg-transparent py-3 px-4 focus:outline-none text-foreground text-[16px] placeholder:text-muted-foreground"
          disabled={isTyping} autoFocus
        />
        <button type="button" onClick={onMicClick} disabled={isTyping}
          className={`p-2.5 rounded-xl transition-all flex-shrink-0 ${isListening ? "bg-red-100 text-red-600 animate-pulse" : "bg-slate-100 text-slate-500 hover:bg-blue-50 hover:text-blue-600"} disabled:opacity-40`}>
          {isListening ? <MicOff size={18}/> : <Mic size={18}/>}
        </button>
        <button type="submit" disabled={isTyping || !text.trim()}
          className="bg-primary hover:bg-primary/90 text-white p-3.5 rounded-xl transition-all disabled:opacity-50 flex-shrink-0">
          <Send size={18} className="ml-0.5"/>
        </button>
      </motion.form>
    );
  };

  return (
    <div className="w-full max-w-2xl mx-auto mt-2 space-y-3">
      {/* ── Language + TTS toggles ── */}
      <div className="flex items-center justify-between px-1">
        <button onClick={onLangToggle}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${
            lang === "te"
              ? "bg-amber-50 border-amber-300 text-amber-700"
              : "bg-blue-50 border-blue-300 text-blue-700"
          }`}
          title="Toggle language / భాష మార్చండి"
        >
          <span>{lang === "te" ? "🇮🇳" : "🌐"}</span>
          {L.langBtn}
        </button>

        <button onClick={onTtsToggle}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
            ttsEnabled
              ? "bg-emerald-50 border-emerald-300 text-emerald-700"
              : "bg-slate-100 border-slate-300 text-slate-500"
          }`}
        >
          {ttsEnabled ? <Volume2 size={13}/> : <VolumeX size={13}/>}
          {ttsEnabled ? L.voiceOn : L.voiceOff}
        </button>
      </div>

      {/* ── Input area ── */}
      <AnimatePresence mode="wait">
        <div key={nextStep}>
          {renderInputArea()}
        </div>
      </AnimatePresence>

      {/* ── Status indicators ── */}
      {isListening && (
        <p className="text-xs text-red-500 text-center animate-pulse font-medium">{L.listening}</p>
      )}
      {isSpeaking && !isListening && (
        <p className="text-xs text-emerald-600 text-center font-medium">{L.reading}</p>
      )}
    </div>
  );
}
