import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar, Clock, User, Phone, CheckCircle, ChevronDown, ChevronUp, Stethoscope } from "lucide-react";
import type { Specialist } from "@workspace/api-client-react";
import type { VoiceLang } from "@/hooks/use-voice";

interface AppointmentBookingProps {
  specialists: Specialist[];
  lang: VoiceLang;
  patientDisease: string;
}

const L: Record<VoiceLang, {
  title: string; subtitle: string; bookBtn: string; doctor: string; selectDoctor: string;
  date: string; time: string; name: string; namePh: string; phone: string; phonePh: string;
  confirm: string; confirmed: string; refId: string; confirmMsg: string; newBooking: string;
  required: string; selectTime: string; available: string;
}> = {
  en: {
    title: "Book an Appointment", subtitle: "Schedule a visit with a recommended specialist",
    bookBtn: "📅 Book Online Appointment", doctor: "Select Doctor",
    selectDoctor: "-- Choose a specialist --", date: "Preferred Date",
    time: "Preferred Time", name: "Patient Name", namePh: "Enter your full name",
    phone: "Mobile Number", phonePh: "10-digit mobile number",
    confirm: "Confirm Appointment", confirmed: "Appointment Confirmed!",
    refId: "Reference ID", confirmMsg: "Your appointment has been scheduled. The clinic will call you 1 hour before to confirm.",
    newBooking: "Book Another Appointment", required: "Please fill all fields.",
    selectTime: "-- Select a time slot --", available: "Available",
  },
  te: {
    title: "అపాయింట్‌మెంట్ బుక్ చేయండి", subtitle: "నిపుణుడిని సందర్శించడానికి షెడ్యూల్ చేయండి",
    bookBtn: "📅 ఆన్‌లైన్ అపాయింట్‌మెంట్ బుక్ చేయండి", doctor: "డాక్టర్ ఎంచుకోండి",
    selectDoctor: "-- నిపుణుడిని ఎంచుకోండి --", date: "పసందైన తేదీ",
    time: "పసందైన సమయం", name: "రోగి పేరు", namePh: "మీ పూర్తి పేరు నమోదు చేయండి",
    phone: "మొబైల్ నంబర్", phonePh: "10 అంకెల మొబైల్ నంబర్",
    confirm: "అపాయింట్‌మెంట్ నిర్ధారించండి", confirmed: "అపాయింట్‌మెంట్ నిర్ధారించబడింది!",
    refId: "రిఫరెన్స్ ID", confirmMsg: "మీ అపాయింట్‌మెంట్ షెడ్యూల్ చేయబడింది. క్లినిక్ 1 గంట ముందు కాల్ చేసి నిర్ధారిస్తుంది.",
    newBooking: "మరొక అపాయింట్‌మెంట్ బుక్ చేయండి", required: "దయచేసి అన్ని వివరాలు నింపండి.",
    selectTime: "-- సమయాన్ని ఎంచుకోండి --", available: "అందుబాటులో ఉంది",
  },
};

const TIME_SLOTS = [
  "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM",
];

function getNext7Days(): { label: string; value: string }[] {
  const days = [];
  const now = new Date();
  const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  for (let i = 1; i <= 7; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    const value = d.toISOString().split("T")[0];
    const label = `${weekdays[d.getDay()]}, ${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
    days.push({ label, value });
  }
  return days;
}

function generateRefId(): string {
  return "ARG-" + Math.random().toString(36).substring(2, 8).toUpperCase();
}

export function AppointmentBooking({ specialists, lang, patientDisease }: AppointmentBookingProps) {
  const [open, setOpen] = useState(false);
  const [doctorIdx, setDoctorIdx] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [confirmed, setConfirmed] = useState<{ refId: string; doctor: string; date: string; time: string; name: string } | null>(null);

  const t = L[lang];
  const days = getNext7Days();

  const bookableSpecialists = specialists.filter(s => s.phone !== "108");

  const handleConfirm = () => {
    if (!doctorIdx || !date || !time || !name.trim() || phone.trim().length < 10) {
      setError(t.required);
      return;
    }
    setError("");
    const sp = bookableSpecialists[parseInt(doctorIdx)];
    setConfirmed({
      refId: generateRefId(),
      doctor: `${sp.name} (${sp.type})`,
      date: days.find(d => d.value === date)?.label ?? date,
      time,
      name: name.trim(),
    });
  };

  const handleReset = () => {
    setConfirmed(null);
    setDoctorIdx(""); setDate(""); setTime(""); setName(""); setPhone(""); setError("");
  };

  return (
    <div className="rounded-2xl border border-teal-200 bg-teal-50 overflow-hidden">
      {/* Header / toggle */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between p-4 hover:bg-teal-100 transition-colors"
      >
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-teal-600 flex items-center justify-center flex-shrink-0">
            <Stethoscope size={16} className="text-white" />
          </div>
          <div className="text-left">
            <p className="font-bold text-sm text-teal-800">{t.title}</p>
            <p className="text-xs text-teal-600">{t.subtitle}</p>
          </div>
        </div>
        {open ? <ChevronUp size={18} className="text-teal-600" /> : <ChevronDown size={18} className="text-teal-600" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-3 border-t border-teal-200">
              {!confirmed ? (
                <>
                  {/* Doctor */}
                  <div className="mt-3">
                    <label className="block text-xs font-bold text-teal-800 mb-1">
                      <User size={12} className="inline mr-1" />{t.doctor}
                    </label>
                    <select
                      value={doctorIdx}
                      onChange={e => setDoctorIdx(e.target.value)}
                      className="w-full rounded-xl border border-teal-300 bg-white text-sm px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    >
                      <option value="">{t.selectDoctor}</option>
                      {bookableSpecialists.map((s, i) => (
                        <option key={i} value={i}>
                          {s.name} — {s.type} · {s.hospital}
                        </option>
                      ))}
                    </select>
                    {doctorIdx && (
                      <p className="text-xs text-teal-600 mt-1 pl-1">
                        🕐 {bookableSpecialists[parseInt(doctorIdx)]?.available}
                      </p>
                    )}
                  </div>

                  {/* Date */}
                  <div>
                    <label className="block text-xs font-bold text-teal-800 mb-1">
                      <Calendar size={12} className="inline mr-1" />{t.date}
                    </label>
                    <select
                      value={date}
                      onChange={e => setDate(e.target.value)}
                      className="w-full rounded-xl border border-teal-300 bg-white text-sm px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    >
                      <option value="">-- Select date --</option>
                      {days.map(d => (
                        <option key={d.value} value={d.value}>{d.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Time */}
                  <div>
                    <label className="block text-xs font-bold text-teal-800 mb-1">
                      <Clock size={12} className="inline mr-1" />{t.time}
                    </label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {TIME_SLOTS.map(slot => (
                        <button
                          key={slot} type="button"
                          onClick={() => setTime(slot)}
                          className={`py-1.5 rounded-lg text-xs font-medium border transition-all ${
                            time === slot
                              ? "bg-teal-600 text-white border-teal-600"
                              : "bg-white text-teal-700 border-teal-300 hover:bg-teal-100"
                          }`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Name */}
                  <div>
                    <label className="block text-xs font-bold text-teal-800 mb-1">
                      <User size={12} className="inline mr-1" />{t.name}
                    </label>
                    <input
                      type="text" value={name} onChange={e => setName(e.target.value)}
                      placeholder={t.namePh}
                      className="w-full rounded-xl border border-teal-300 bg-white text-sm px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-bold text-teal-800 mb-1">
                      <Phone size={12} className="inline mr-1" />{t.phone}
                    </label>
                    <input
                      type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                      placeholder={t.phonePh} maxLength={10}
                      className="w-full rounded-xl border border-teal-300 bg-white text-sm px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-400"
                    />
                  </div>

                  {error && <p className="text-xs text-red-600 font-medium">{error}</p>}

                  <button
                    onClick={handleConfirm}
                    className="w-full py-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm transition-all shadow-md"
                  >
                    {t.confirm}
                  </button>
                </>
              ) : (
                /* Confirmation screen */
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                  className="mt-3 bg-white rounded-2xl border border-emerald-200 p-5 text-center"
                >
                  <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-3">
                    <CheckCircle size={24} className="text-emerald-600" />
                  </div>
                  <h4 className="font-bold text-emerald-800 text-base mb-1">{t.confirmed}</h4>
                  <p className="text-xs text-emerald-600 mb-4">{t.confirmMsg}</p>

                  <div className="bg-emerald-50 rounded-xl p-3 text-left space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.refId}</span>
                      <span className="font-bold text-emerald-700">{confirmed.refId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Patient</span>
                      <span className="font-semibold">{confirmed.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Doctor</span>
                      <span className="font-semibold text-right max-w-[55%]">{confirmed.doctor}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date</span>
                      <span className="font-semibold">{confirmed.date}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time</span>
                      <span className="font-semibold">{confirmed.time}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleReset}
                    className="mt-4 w-full py-2.5 rounded-xl border border-teal-300 text-teal-700 text-xs font-semibold hover:bg-teal-50 transition-colors"
                  >
                    {t.newBooking}
                  </button>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
