/**
 * Chatbot route — English (en) and Telugu (te)
 * Flow: greeting → name → heartRate → spo2 → systolicBP → diastolicBP →
 *        temperature → fallDetection → symptomDays → breathShortness →
 *        chestPain → familyHistory → predicting → done
 */

import { Router, type IRouter } from "express";
import {
  SendChatMessageBody,
  SendChatMessageResponse,
  PredictHealthBody,
  PredictHealthResponse,
} from "@workspace/api-zod";
import { predict, type VitalsInput } from "../lib/mlPredictor.js";

const router: IRouter = Router();

type Step =
  | "greeting" | "name" | "heartRate" | "spo2" | "systolicBP" | "diastolicBP"
  | "temperature" | "fallDetection" | "symptomDays" | "breathShortness"
  | "chestPain" | "familyHistory" | "predicting" | "done";
type Lang = "en" | "te";

interface SessionState {
  step: Step;
  lang: Lang;
  name?: string;
  heartRate?: number;
  spo2?: number;
  systolicBP?: number;
  diastolicBP?: number;
  temperature?: number;
  fallDetected?: boolean;
  symptomDays?: number;
  breathShortness?: boolean;
  chestPain?: boolean;
  familyHistory?: boolean;
}

const sessions = new Map<string, SessionState>();

// ── Translations ────────────────────────────────────────────────────────────
const T: Record<string, Record<Lang, (...args: any[]) => string>> = {
  greeting: {
    en: () =>
      `👋 Hello! I'm **Arogya AI** — your Virtual Health Assistant.\n\nI'll collect your vitals and run an AI analysis to predict — *Heart Disease*, *Asthma*, *Hypertension*, *Diabetes Mellitus*, or confirm you're *Healthy*.\n\nLet's begin — what's your name?`,
    te: () =>
      `👋 నమస్కారం! నేను **ఆరోగ్య AI** — మీ వర్చువల్ హెల్త్ అసిస్టెంట్.\n\nమీ ఆరోగ్య వివరాలను సేకరించి AI విశ్లేషణ చేస్తాను — *గుండె జబ్బు*, *ఆస్తమా*, *రక్తపోటు*, *డయాబెటిస్* లేదా మీరు *ఆరోగ్యంగా* ఉన్నారో నిర్ధారిస్తాను.\n\nమొదలు పెట్టడానికి — మీ పేరు ఏమిటి?`,
  },
  name: {
    en: (n: string) =>
      `Nice to meet you, **${n}**! 😊\n\nI'll collect **6 vitals** — one at a time. You can type or use the **microphone**.\n\n❤️ **Heart Rate** — What is your current heart rate in BPM?\n\n_Normal: 60–100 BPM_`,
    te: (n: string) =>
      `మిమ్మల్ని కలిసినందుకు సంతోషం, **${n}**! 😊\n\n**6 ఆరోగ్య వివరాలు** సేకరిస్తాను. టైప్ చేయండి లేదా **మైక్రోఫోన్** వాడండి.\n\n❤️ **గుండె స్పందన రేటు** — మీ ప్రస్తుత హృదయ స్పందన రేటు BPM లో ఎంత?\n\n_సాధారణ: 60–100 BPM_`,
  },
  hrInvalid: {
    en: () => `Please enter a valid heart rate in BPM (20–300). Example: **72**`,
    te: () => `దయచేసి సరైన హృదయ స్పందన రేటు నమోదు చేయండి (20–300). ఉదా: **72**`,
  },
  hrOk: {
    en: (v: number, al: string) =>
      `Recorded: **${v} BPM** — ${al}\n\n🫁 **SpO2 (Blood Oxygen Saturation)** — What is your oxygen level %?\n\n_Normal: 95–100%_`,
    te: (v: number, al: string) =>
      `నమోదు: **${v} BPM** — ${al}\n\n🫁 **SpO2 (ఆక్సిజన్ స్థాయి)** — మీ ఆక్సిజన్ శాతం ఎంత?\n\n_సాధారణ: 95–100%_`,
  },
  spo2Invalid: {
    en: () => `Please enter a valid SpO2 percentage (50–100). Example: **98**`,
    te: () => `దయచేసి సరైన SpO2 శాతం నమోదు చేయండి (50–100). ఉదా: **98**`,
  },
  spo2Ok: {
    en: (v: number, al: string) =>
      `Recorded: **${v}%** SpO2 — ${al}\n\n🩺 **Systolic BP** — Enter the upper blood pressure reading in mmHg.\n\n_Normal: below 130 mmHg_`,
    te: (v: number, al: string) =>
      `నమోదు: **${v}%** SpO2 — ${al}\n\n🩺 **సిస్టోలిక్ రక్తపోటు** — పైన ఉన్న రక్తపోటు mmHg లో నమోదు చేయండి.\n\n_సాధారణ: 130 mmHg కంటే తక్కువ_`,
  },
  sysInvalid: {
    en: () => `Please enter a valid systolic BP in mmHg (50–300). Example: **120**`,
    te: () => `దయచేసి సరైన సిస్టోలిక్ రక్తపోటు mmHg లో నమోదు చేయండి (50–300). ఉదా: **120**`,
  },
  sysOk: {
    en: (v: number, al: string) =>
      `Recorded: **${v} mmHg** systolic — ${al}\n\n🩺 **Diastolic BP** — Enter the lower blood pressure reading in mmHg.\n\n_Normal: below 90 mmHg_`,
    te: (v: number, al: string) =>
      `నమోదు: **${v} mmHg** సిస్టోలిక్ — ${al}\n\n🩺 **డయాస్టోలిక్ రక్తపోటు** — కిందన ఉన్న రక్తపోటు mmHg లో నమోదు చేయండి.\n\n_సాధారణ: 90 mmHg కంటే తక్కువ_`,
  },
  diaInvalid: {
    en: () => `Please enter a valid diastolic BP in mmHg (30–200). Example: **80**`,
    te: () => `దయచేసి సరైన డయాస్టోలిక్ BP mmHg లో నమోదు చేయండి (30–200). ఉదా: **80**`,
  },
  diaOk: {
    en: (dia: number, sys: number, al: string) =>
      `Recorded: **${dia} mmHg** diastolic — BP ${sys}/${dia} overall: ${al}\n\n🌡️ **Body Temperature** — Enter your temperature in °C.\n\n_Normal: 36.1–37.2°C_`,
    te: (dia: number, sys: number, al: string) =>
      `నమోదు: **${dia} mmHg** డయాస్టోలిక్ — BP ${sys}/${dia} మొత్తం: ${al}\n\n🌡️ **శరీర ఉష్ణోగ్రత** — మీ ఉష్ణోగ్రత °C లో నమోదు చేయండి.\n\n_సాధారణ: 36.1–37.2°C_`,
  },
  tempInvalid: {
    en: () => `Please enter a valid body temperature in °C (30–45). Example: **36.8**`,
    te: () => `దయచేసి సరైన శరీర ఉష్ణోగ్రత °C లో నమోదు చేయండి (30–45). ఉదా: **36.8**`,
  },
  tempOk: {
    en: (v: number, al: string) =>
      `Recorded: **${v}°C** — ${al}\n\n⚠️ **Fall Detection** — Have you experienced any fall or sudden loss of balance recently?`,
    te: (v: number, al: string) =>
      `నమోదు: **${v}°C** — ${al}\n\n⚠️ **పడిపోవడం** — ఇటీవల మీకు పడిపోవడం లేదా తూలుకొనే అనుభవం వచ్చిందా?`,
  },
  fallOk: {
    en: (fell: boolean) =>
      `${fell ? "⚠️ Fall recorded.\n\n" : ""}✅ Vitals collected! Now a few quick clinical questions.\n\n📅 **How many days** have you been experiencing these health issues?\n\n_Enter 0 if this is a new/sudden issue today_`,
    te: (fell: boolean) =>
      `${fell ? "⚠️ పడిపోవడం నమోదు చేయబడింది.\n\n" : ""}✅ వైటల్స్ సేకరించాం! ఇప్పుడు కొన్ని వైద్య ప్రశ్నలు.\n\n📅 **ఎన్ని రోజుల నుండి** ఈ ఆరోగ్య సమస్యలు ఉన్నాయి?\n\n_ఈరోజే కొత్తగా వస్తే 0 నమోదు చేయండి_`,
  },
  sysDaysInvalid: {
    en: () => `Please enter a valid number of days (0–3650). Example: **3** for 3 days, **0** if sudden.`,
    te: () => `దయచేసి సరైన రోజుల సంఖ్య నమోదు చేయండి (0–3650). ఉదా: **3** కోసం 3 రోజులు.`,
  },
  sysDaysOk: {
    en: (d: number) => {
      const label = d === 0 ? "today/sudden" : d === 1 ? "1 day" : `${d} days`;
      return `Recorded: **${label}** of symptoms.\n\n🌬️ **Shortness of Breath** — Do you experience difficulty breathing or shortness of breath?`;
    },
    te: (d: number) => {
      const label = d === 0 ? "ఈరోజు/అకస్మాత్తుగా" : `${d} రోజుల నుండి`;
      return `నమోదు: **${label}** లక్షణాలు.\n\n🌬️ **శ్వాస సమస్య** — మీకు శ్వాస తీసుకోవడంలో ఇబ్బంది లేదా అల్పశ్వాస వస్తుందా?`;
    },
  },
  breathOk: {
    en: (v: boolean) =>
      `Recorded: Shortness of breath — **${v ? "Yes" : "No"}**.\n\n💔 **Chest Pain** — Do you experience chest pain, pressure, or tightness?`,
    te: (v: boolean) =>
      `నమోదు: శ్వాస సమస్య — **${v ? "అవును" : "కాదు"}**.\n\n💔 **ఛాతీ నొప్పి** — మీకు ఛాతీ నొప్పి, ఒత్తిడి లేదా బిగుతుగా అనిపిస్తుందా?`,
  },
  chestOk: {
    en: (v: boolean) =>
      `Recorded: Chest pain — **${v ? "Yes" : "No"}**.\n\n👨‍👩‍👧 **Family History** — Does your family have a history of heart disease, high BP, or diabetes?`,
    te: (v: boolean) =>
      `నమోదు: ఛాతీ నొప్పి — **${v ? "అవును" : "కాదు"}**.\n\n👨‍👩‍👧 **కుటుంబ చరిత్ర** — మీ కుటుంబంలో గుండె జబ్బు, అధిక రక్తపోటు లేదా డయాబెటిస్ చరిత్ర ఉందా?`,
  },
  predicting: {
    en: (name: string) =>
      `✅ **All data collected!** Thank you, ${name}.\n\n━━━━━━━━━━━━━━━━━━\n🔬 **Running AI analysis on your vitals and symptoms...**\nDecision Tree model processing — please wait...\n━━━━━━━━━━━━━━━━━━`,
    te: (name: string) =>
      `✅ **అన్ని వివరాలు సేకరించాం!** ధన్యవాదాలు, ${name}.\n\n━━━━━━━━━━━━━━━━━━\n🔬 **మీ వైటల్స్ మరియు లక్షణాలపై AI విశ్లేషణ చేస్తోంది...**\nనిర్ణయ వృక్ష నమూనా అమలు చేస్తోంది — వేచి ఉండండి...\n━━━━━━━━━━━━━━━━━━`,
  },
  done: {
    en: () => `Assessment complete. Click **"Start New Assessment"** to begin again.`,
    te: () => `పరీక్ష పూర్తయింది. మళ్ళీ మొదలు పెట్టడానికి **"కొత్త పరీక్ష"** క్లిక్ చేయండి.`,
  },
  normalAlert: { en: () => "✅ NORMAL", te: () => "✅ సాధారణం" },
  abnormalAlert: { en: () => "⚠️ ABNORMAL", te: () => "⚠️ అసాధారణం" },
};

function t(key: string, lang: Lang, ...args: any[]): string {
  return T[key]?.[lang]?.(...args) ?? "";
}

function alertStr(abnormal: boolean, lang: Lang): string {
  return abnormal ? t("abnormalAlert", lang) : t("normalAlert", lang);
}

function parseYesNo(msg: string): boolean {
  return /\b(yes|y|yeah|yep|yup|true|1|అవును|హా|అవు|ఆ)\b/i.test(msg.trim());
}

function parseNum(msg: string): number | null {
  const n = parseFloat(msg.replace(/[^\d.]/g, ""));
  return isNaN(n) ? null : n;
}

// ── /chat ──────────────────────────────────────────────────────────────────
router.post("/chat", (req, res) => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }

  const { message, sessionId, language } = parsed.data;
  const lang: Lang = (language as Lang) ?? "en";
  const msg = message.trim();

  if (!sessions.has(sessionId)) sessions.set(sessionId, { step: "greeting", lang });
  const s = sessions.get(sessionId)!;
  s.lang = lang;

  let reply = "";
  let nextStep: Step = s.step;
  let vitalsReady = false;
  let vitals: VitalsInput | undefined;

  switch (s.step) {
    // ── Intro ──────────────────────────────────────────────────────────────
    case "greeting":
      reply = t("greeting", lang);
      s.step = "name"; nextStep = "name";
      break;

    case "name":
      s.name = msg || (lang === "te" ? "మిత్రుడు" : "Friend");
      reply = t("name", lang, s.name);
      s.step = "heartRate"; nextStep = "heartRate";
      break;

    // ── Vitals ─────────────────────────────────────────────────────────────
    case "heartRate": {
      const v = parseNum(msg);
      if (!v || v < 20 || v > 300) { reply = t("hrInvalid", lang); nextStep = "heartRate"; break; }
      s.heartRate = v;
      reply = t("hrOk", lang, v, alertStr(v < 60 || v > 100, lang));
      s.step = "spo2"; nextStep = "spo2";
      break;
    }
    case "spo2": {
      const v = parseNum(msg);
      if (!v || v < 50 || v > 100) { reply = t("spo2Invalid", lang); nextStep = "spo2"; break; }
      s.spo2 = v;
      reply = t("spo2Ok", lang, v, alertStr(v < 95, lang));
      s.step = "systolicBP"; nextStep = "systolicBP";
      break;
    }
    case "systolicBP": {
      const v = parseNum(msg);
      if (!v || v < 50 || v > 300) { reply = t("sysInvalid", lang); nextStep = "systolicBP"; break; }
      s.systolicBP = v;
      reply = t("sysOk", lang, v, alertStr(v >= 140, lang));
      s.step = "diastolicBP"; nextStep = "diastolicBP";
      break;
    }
    case "diastolicBP": {
      const v = parseNum(msg);
      if (!v || v < 30 || v > 200) { reply = t("diaInvalid", lang); nextStep = "diastolicBP"; break; }
      s.diastolicBP = v;
      const bpAbn = (s.systolicBP ?? 0) >= 140 || v >= 90;
      reply = t("diaOk", lang, v, s.systolicBP ?? 0, alertStr(bpAbn, lang));
      s.step = "temperature"; nextStep = "temperature";
      break;
    }
    case "temperature": {
      const v = parseNum(msg);
      if (!v || v < 30 || v > 45) { reply = t("tempInvalid", lang); nextStep = "temperature"; break; }
      s.temperature = v;
      reply = t("tempOk", lang, v, alertStr(v > 37.5, lang));
      s.step = "fallDetection"; nextStep = "fallDetection";
      break;
    }
    case "fallDetection": {
      const fell = parseYesNo(msg);
      s.fallDetected = fell;
      reply = t("fallOk", lang, fell);
      s.step = "symptomDays"; nextStep = "symptomDays";
      break;
    }

    // ── Clinical questions ─────────────────────────────────────────────────
    case "symptomDays": {
      const v = parseNum(msg);
      if (v === null || v < 0 || v > 3650) { reply = t("sysDaysInvalid", lang); nextStep = "symptomDays"; break; }
      s.symptomDays = v;
      reply = t("sysDaysOk", lang, v);
      s.step = "breathShortness"; nextStep = "breathShortness";
      break;
    }
    case "breathShortness": {
      const v = parseYesNo(msg);
      s.breathShortness = v;
      reply = t("breathOk", lang, v);
      s.step = "chestPain"; nextStep = "chestPain";
      break;
    }
    case "chestPain": {
      const v = parseYesNo(msg);
      s.chestPain = v;
      reply = t("chestOk", lang, v);
      s.step = "familyHistory"; nextStep = "familyHistory";
      break;
    }
    case "familyHistory": {
      const v = parseYesNo(msg);
      s.familyHistory = v;
      vitalsReady = true;
      vitals = {
        heartRate: s.heartRate!,
        spo2: s.spo2!,
        systolicBP: s.systolicBP!,
        diastolicBP: s.diastolicBP!,
        temperature: s.temperature!,
        fallDetected: s.fallDetected!,
        symptomDays: s.symptomDays,
        breathShortness: s.breathShortness,
        chestPain: s.chestPain,
        familyHistory: v,
      };
      reply = t("predicting", lang, s.name ?? (lang === "te" ? "మిత్రుడు" : "Friend"));
      s.step = "predicting"; nextStep = "predicting";
      break;
    }

    case "predicting":
    case "done":
      reply = t("done", lang); nextStep = "done";
      break;
  }

  const response = SendChatMessageResponse.parse({
    reply, sessionId, nextStep, vitalsReady,
    ...(vitals ? { vitals } : {}),
  });
  res.json(response);
});

// ── /predict ───────────────────────────────────────────────────────────────
router.post("/predict", (req, res) => {
  const parsed = PredictHealthBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request" }); return; }
  const response = PredictHealthResponse.parse(predict(parsed.data));
  res.json(response);
});

export default router;
