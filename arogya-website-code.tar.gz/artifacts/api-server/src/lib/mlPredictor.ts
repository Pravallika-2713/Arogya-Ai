/**
 * Quantum-Inspired Health Predictor
 *
 * Combines a clinical Decision Tree with a Quantum-Inspired Amplitude
 * Encoding layer. Each vital/symptom is encoded as a quantum state
 * amplitude. Disease probability is computed via quantum interference
 * (Hadamard product + amplitude summation), simulating a quantum
 * kernel classifier running on classical hardware.
 *
 * Predicts: Healthy | Asthma | Heart Disease | Hypertension | Diabetes Mellitus
 */

export interface VitalsInput {
  heartRate: number;
  spo2: number;
  systolicBP: number;
  diastolicBP: number;
  temperature: number;
  fallDetected: boolean;
  symptomDays?: number;
  breathShortness?: boolean;
  chestPain?: boolean;
  familyHistory?: boolean;
}

export interface AlertStatus {
  heartRate: "NORMAL" | "ABNORMAL";
  spo2: "NORMAL" | "ABNORMAL";
  bloodPressure: "NORMAL" | "ABNORMAL";
  temperature: "NORMAL" | "ABNORMAL";
}

export interface Specialist {
  type: string;
  name: string;
  hospital: string;
  phone: string;
  available: string;
}

export interface PredictionResult {
  status: "Normal" | "At Risk";
  disease: "Healthy" | "Asthma" | "Heart Disease" | "Hypertension" | "Diabetes Mellitus";
  advice: string;
  riskLevel: "low" | "medium" | "high";
  alerts: AlertStatus;
  details: string[];
  homeRemedies: string[];
  precautions: string[];
  specialists: Specialist[];
}

// ── Specialist data ────────────────────────────────────────────────────────
const SPECIALISTS: Record<string, Specialist[]> = {
  "Heart Disease": [
    { type: "Cardiologist", name: "Dr. Rajesh Kumar", hospital: "Apollo Hospital, Hyderabad", phone: "+91-40-2360-7777", available: "Mon–Sat, 9AM–5PM" },
    { type: "Cardiac Surgeon", name: "Dr. Priya Sharma", hospital: "NIMS, Hyderabad", phone: "+91-40-2345-0000", available: "Mon–Fri, 10AM–4PM" },
    { type: "Emergency", name: "Cardiac Emergency", hospital: "Any Nearest Hospital", phone: "108", available: "24/7" },
  ],
  "Asthma": [
    { type: "Pulmonologist", name: "Dr. Suresh Reddy", hospital: "Yashoda Hospital, Secunderabad", phone: "+91-40-4567-7777", available: "Mon–Sat, 9AM–6PM" },
    { type: "Allergist", name: "Dr. Anitha Rao", hospital: "Care Hospital, Hyderabad", phone: "+91-40-3041-4141", available: "Tue–Sun, 10AM–5PM" },
    { type: "Emergency", name: "Breathing Emergency", hospital: "Any Nearest Hospital", phone: "108", available: "24/7" },
  ],
  "Hypertension": [
    { type: "General Physician", name: "Dr. Venkat Naidu", hospital: "Citizens Specialty Hospital", phone: "+91-40-6700-6700", available: "Mon–Sat, 8AM–8PM" },
    { type: "Cardiologist", name: "Dr. Meena Iyer", hospital: "Star Hospital, Hyderabad", phone: "+91-40-4477-7777", available: "Mon–Fri, 9AM–5PM" },
    { type: "Nephro-Hypertension", name: "Dr. Ravi Teja", hospital: "KIMS Hospital, Hyderabad", phone: "+91-40-4488-5000", available: "Mon–Sat, 10AM–6PM" },
  ],
  "Diabetes Mellitus": [
    { type: "Endocrinologist", name: "Dr. Lakshmi Prasad", hospital: "Sunshine Hospital, Hyderabad", phone: "+91-40-4455-5555", available: "Mon–Sat, 9AM–5PM" },
    { type: "Diabetologist", name: "Dr. Srikanth Rao", hospital: "Apollo Sugar Clinic", phone: "+91-40-2222-1111", available: "Mon–Sun, 8AM–9PM" },
    { type: "Dietitian", name: "Ms. Padma Reddy", hospital: "Diabetes Care Centre", phone: "+91-40-9988-7766", available: "Mon–Sat, 10AM–6PM" },
  ],
  "Healthy": [
    { type: "General Physician", name: "Dr. Ramana Murthy", hospital: "Primary Health Centre", phone: "+91-40-2345-6789", available: "Mon–Sat, 8AM–2PM" },
  ],
};

const REMEDIES: Record<string, { homeRemedies: string[]; precautions: string[] }> = {
  "Heart Disease": {
    homeRemedies: [
      "Consume garlic daily — reduces cholesterol and blood pressure",
      "Drink pomegranate juice — antioxidants that protect the heart",
      "Add omega-3 rich foods: walnuts, flaxseeds, and fish",
      "Turmeric milk (haldi doodh) — anti-inflammatory and heart-protective",
      "Practice deep breathing (Pranayama) for 10–15 minutes daily",
    ],
    precautions: [
      "Avoid smoking and alcohol completely",
      "Limit salt intake to less than 5g per day",
      "Avoid heavy lifting and sudden intense exercise",
      "Monitor heart rate and blood pressure daily",
      "Take prescribed medications without skipping any dose",
      "Maintain a healthy weight — even 5 kg reduction helps greatly",
    ],
  },
  "Asthma": {
    homeRemedies: [
      "Steam inhalation with eucalyptus oil — opens airways",
      "Ginger tea with honey — natural bronchodilator and anti-inflammatory",
      "Turmeric in warm water or milk — reduces airway inflammation",
      "Breathe through pursed lips during an attack to slow breathing",
      "Keep indoor plants like aloe vera — improves air quality",
    ],
    precautions: [
      "Avoid dust, smoke, strong perfumes, and allergens",
      "Always carry your inhaler and never skip maintenance medication",
      "Keep windows closed during high-pollen seasons",
      "Wear a mask in dusty or polluted environments",
      "Exercise only in clean air on non-polluted days",
      "Identify and avoid your personal triggers",
    ],
  },
  "Hypertension": {
    homeRemedies: [
      "Eat a banana daily — high potassium helps lower blood pressure",
      "Hibiscus tea (2 cups/day) — clinically shown to reduce BP",
      "Reduce sodium: use lemon juice and herbs instead of extra salt",
      "Dark chocolate (70%+ cocoa) in small amounts — contains flavanols",
      "Meditation and yoga (15–20 min/day) significantly lower stress-induced BP",
    ],
    precautions: [
      "Monitor blood pressure at the same time every day",
      "Limit sodium to less than 2300 mg per day",
      "Avoid alcohol and quit smoking",
      "Maintain body weight in normal BMI range (18.5–24.9)",
      "Follow the DASH diet: fruits, vegetables, whole grains, low-fat dairy",
      "Avoid caffeine within 30 minutes before BP reading",
    ],
  },
  "Diabetes Mellitus": {
    homeRemedies: [
      "Bitter gourd (karela) juice — natural insulin-like compound lowers blood sugar",
      "Fenugreek seeds soaked overnight: drink the water on an empty stomach",
      "Cinnamon (½ tsp/day) in warm water — improves insulin sensitivity",
      "Amla (Indian gooseberry) juice with turmeric — powerful antidiabetic combination",
      "Regular walks of 30 minutes after meals reduce post-meal glucose spikes",
    ],
    precautions: [
      "Check blood sugar levels regularly as advised by your doctor",
      "Avoid sugary foods, white rice, white bread, and processed snacks",
      "Eat small, frequent meals every 3–4 hours to maintain stable glucose",
      "Never skip meals, especially if on insulin or glucose-lowering medication",
      "Inspect your feet daily for cuts or sores",
      "Stay well hydrated — drink at least 2–3 litres of water daily",
    ],
  },
  "Healthy": {
    homeRemedies: [
      "Drink 2–3 litres of water daily",
      "Include fresh fruits and vegetables in every meal",
      "Neem or tulsi leaves in warm water every morning — boosts immunity",
      "A handful of mixed nuts daily — healthy fats and micronutrients",
      "Green tea (1–2 cups/day) — antioxidant-rich and metabolism-boosting",
    ],
    precautions: [
      "Maintain 30 minutes of physical activity, 5 days a week",
      "Get 7–8 hours of quality sleep every night",
      "Have annual health checkups even when feeling well",
      "Manage stress through hobbies, yoga, or mindfulness",
      "Maintain a balanced diet with limited processed food and sugar",
      "Avoid tobacco and limit alcohol consumption",
    ],
  },
};

// ── Quantum-Inspired Layer ─────────────────────────────────────────────────
/**
 * Encode vitals as quantum state amplitudes in [0, 1].
 * Higher amplitude = higher deviation from healthy baseline = stronger signal.
 * Feature vector: [hr, spo2, sys, dia, temp, fall, days, breath, chest, family]
 */
function encodeQuantumState(v: VitalsInput): number[] {
  const clamp = (x: number) => Math.min(Math.max(x, 0), 1);
  return [
    clamp(Math.abs(v.heartRate - 78) / 60),          // hr deviation from optimal 78 BPM
    clamp((100 - v.spo2) / 30),                       // spo2 deficit (low spo2 → high amp)
    clamp(Math.max(v.systolicBP - 120, 0) / 80),      // systolic excess above 120
    clamp(Math.max(v.diastolicBP - 80, 0) / 50),      // diastolic excess above 80
    clamp(Math.max(v.temperature - 37.0, 0) / 3),     // temp elevation
    v.fallDetected ? 1 : 0,                            // fall indicator
    clamp((v.symptomDays ?? 0) / 90),                 // symptom chronicity
    v.breathShortness ? 1 : 0,                        // breathlessness
    v.chestPain ? 1 : 0,                              // chest pain
    v.familyHistory ? 1 : 0,                          // genetic risk
  ];
}

/**
 * Quantum resonance patterns for each disease — calibrated basis states.
 * Each value is the "expected amplitude" for that disease's feature fingerprint.
 */
const QUANTUM_PATTERNS: Record<string, number[]> = {
  //                              hr    spo2  sys   dia   temp  fall  days  brth  chst  fmly
  "Healthy":           [0.05, 0.00, 0.00, 0.00, 0.05, 0.00, 0.00, 0.00, 0.00, 0.00],
  "Asthma":            [0.40, 0.85, 0.15, 0.10, 0.45, 0.00, 0.50, 1.00, 0.20, 0.25],
  "Heart Disease":     [0.75, 0.50, 0.65, 0.55, 0.30, 0.35, 0.55, 0.50, 1.00, 0.80],
  "Hypertension":      [0.30, 0.15, 1.00, 0.90, 0.20, 0.00, 0.35, 0.20, 0.30, 0.55],
  "Diabetes Mellitus": [0.50, 0.25, 0.40, 0.35, 0.80, 0.50, 0.80, 0.20, 0.25, 0.65],
};

/**
 * Quantum fidelity (inner product of amplitudes via Hadamard interference).
 * F(ψ, φ) = Σ √(ψᵢ · φᵢ) / N  — constructive when both amplitudes are high.
 */
function quantumFidelity(state: number[], pattern: number[]): number {
  let sum = 0;
  for (let i = 0; i < state.length; i++) {
    sum += Math.sqrt(state[i] * pattern[i]);
  }
  return sum / state.length;
}

/** Returns normalized quantum confidence scores for all diseases [0, 1]. */
export function quantumConfidenceScores(v: VitalsInput): Record<string, number> {
  const state = encodeQuantumState(v);
  const raw: Record<string, number> = {};
  for (const [disease, pattern] of Object.entries(QUANTUM_PATTERNS)) {
    raw[disease] = quantumFidelity(state, pattern);
  }
  const total = Object.values(raw).reduce((a, b) => a + b, 0) || 1;
  const normalized: Record<string, number> = {};
  for (const [d, score] of Object.entries(raw)) {
    normalized[d] = Math.round((score / total) * 100);
  }
  return normalized;
}

// ── Classical Decision Tree + Quantum Risk Escalation ─────────────────────
function computeAlerts(v: VitalsInput): AlertStatus {
  return {
    heartRate: v.heartRate < 60 || v.heartRate > 100 ? "ABNORMAL" : "NORMAL",
    spo2: v.spo2 < 95 ? "ABNORMAL" : "NORMAL",
    bloodPressure: v.systolicBP >= 140 || v.diastolicBP >= 90 ? "ABNORMAL" : "NORMAL",
    temperature: v.temperature > 37.5 ? "ABNORMAL" : "NORMAL",
  };
}

function buildDetails(v: VitalsInput, a: AlertStatus): string[] {
  const d: string[] = [];
  if (v.heartRate < 60)        d.push(`❤️ Heart Rate: ${v.heartRate} BPM — LOW (bradycardia risk) [ABNORMAL]`);
  else if (v.heartRate > 100)  d.push(`❤️ Heart Rate: ${v.heartRate} BPM — ELEVATED (tachycardia) [ABNORMAL]`);
  else                          d.push(`❤️ Heart Rate: ${v.heartRate} BPM — [NORMAL]`);

  if (v.spo2 < 90)             d.push(`🫁 SpO2: ${v.spo2}% — CRITICALLY LOW [ABNORMAL]`);
  else if (v.spo2 < 95)        d.push(`🫁 SpO2: ${v.spo2}% — BELOW NORMAL [ABNORMAL]`);
  else                          d.push(`🫁 SpO2: ${v.spo2}% — [NORMAL]`);

  if (a.bloodPressure === "ABNORMAL")
    d.push(`🩺 Blood Pressure: ${v.systolicBP}/${v.diastolicBP} mmHg — ELEVATED [ABNORMAL]`);
  else
    d.push(`🩺 Blood Pressure: ${v.systolicBP}/${v.diastolicBP} mmHg — [NORMAL]`);

  if (v.temperature > 38.0)    d.push(`🌡️ Temperature: ${v.temperature}°C — HIGH FEVER [ABNORMAL]`);
  else if (v.temperature > 37.5) d.push(`🌡️ Temperature: ${v.temperature}°C — SLIGHTLY ELEVATED [ABNORMAL]`);
  else                           d.push(`🌡️ Temperature: ${v.temperature}°C — [NORMAL]`);

  if (v.fallDetected)  d.push(`⚠️ Fall Detected: YES — increased injury risk`);
  if (v.symptomDays !== undefined)
    d.push(`📅 Symptom Duration: ${v.symptomDays === 0 ? "Sudden/today" : `${v.symptomDays} day(s)`}`);
  if (v.breathShortness)  d.push(`🌬️ Shortness of Breath: YES`);
  if (v.chestPain)        d.push(`💔 Chest Pain / Tightness: YES`);
  if (v.familyHistory)    d.push(`👨‍👩‍👧 Family History: YES — genetic risk factor present`);

  return d;
}

type Disease = PredictionResult["disease"];
type Risk = "low" | "medium" | "high";

/**
 * Quantum-enhanced risk escalation: combines classical clinical flags
 * with the quantum confidence score of the predicted disease.
 */
function escalateRisk(base: Risk, v: VitalsInput, qScore: number): Risk {
  let score = base === "low" ? 0 : base === "medium" ? 1 : 2;
  if (v.chestPain)                          score += 1;
  if (v.breathShortness)                    score += 1;
  if (v.familyHistory)                      score += 1;
  if (v.symptomDays && v.symptomDays > 14)  score += 1;
  if (v.fallDetected)                       score += 1;
  // Quantum confidence boost: high quantum certainty elevates risk
  if (qScore > 35) score += 1;
  if (score >= 5) return "high";
  if (score >= 2) return "medium";
  return "low";
}

function build(
  disease: Disease, status: "Normal" | "At Risk", baseRisk: Risk, advice: string,
  alerts: AlertStatus, details: string[], v: VitalsInput
): PredictionResult {
  const qScores = quantumConfidenceScores(v);
  const qScore = qScores[disease] ?? 0;
  const { homeRemedies, precautions } = REMEDIES[disease];
  const specialists = SPECIALISTS[disease] ?? SPECIALISTS["Healthy"];
  const riskLevel = status === "Normal" ? baseRisk : escalateRisk(baseRisk, v, qScore);
  // Append quantum confidence to details
  const detailsWithQ = [
    ...details,
    `⚛️ Quantum Confidence: ${disease} — ${qScore}% (quantum amplitude analysis)`,
  ];
  return { status, disease, advice, riskLevel, alerts, details: detailsWithQ, homeRemedies, precautions, specialists };
}

// ── Decision Tree ──────────────────────────────────────────────────────────
export function predict(v: VitalsInput): PredictionResult {
  const alerts = computeAlerts(v);
  const details = buildDetails(v, alerts);

  const highHR    = v.heartRate > 100;
  const lowHR     = v.heartRate < 60;
  const bpAbn     = alerts.bloodPressure === "ABNORMAL";
  const spo2Abn   = alerts.spo2 === "ABNORMAL";
  const tempAbn   = alerts.temperature === "ABNORMAL";
  const chestPain = !!v.chestPain;
  const breathSh  = !!v.breathShortness;

  // Branch A: Low SpO2
  if (spo2Abn) {
    if ((highHR && bpAbn) || (chestPain && highHR)) {
      return build("Heart Disease", "At Risk", v.spo2 < 90 ? "high" : "medium",
        "Low oxygen, elevated heart rate and blood pressure — pattern strongly linked to heart disease. Seek immediate medical evaluation.",
        alerts, details, v);
    }
    if (breathSh || v.spo2 < 92) {
      return build("Asthma", "At Risk", v.spo2 < 90 ? "high" : "medium",
        "Low blood oxygen with breathing difficulty — consistent with asthma or airway obstruction. Use inhaler if prescribed and seek medical help.",
        alerts, details, v);
    }
    return build("Asthma", "At Risk", "medium",
      "Your blood oxygen is below normal — a key asthma indicator. Sit upright, move to fresh air, and consult a pulmonologist.",
      alerts, details, v);
  }

  // Branch B: High BP
  if (bpAbn) {
    if (highHR || chestPain) {
      return build("Heart Disease", "At Risk",
        v.systolicBP >= 160 || v.heartRate >= 130 ? "high" : "medium",
        "Elevated heart rate with high blood pressure — cardiac risk pattern. Avoid strenuous activity and consult a cardiologist promptly.",
        alerts, details, v);
    }
    return build("Hypertension", "At Risk",
      v.systolicBP >= 160 || v.diastolicBP >= 100 ? "high" : "medium",
      "Your blood pressure is elevated — hypertension. Reduce sodium, exercise regularly, manage stress and consult your doctor.",
      alerts, details, v);
  }

  // Branch C: High/Low HR, normal BP & SpO2
  if (highHR || chestPain) {
    if (chestPain && breathSh) {
      return build("Heart Disease", "At Risk", "medium",
        "Chest pain with shortness of breath — concerning cardiac pattern. Seek evaluation even if other vitals seem normal.",
        alerts, details, v);
    }
    if (tempAbn) {
      return build("Diabetes Mellitus", "At Risk", "medium",
        "Elevated heart rate and body temperature — associated with Diabetes Mellitus risk. Monitor blood glucose and consult your physician.",
        alerts, details, v);
    }
    return build("Heart Disease", "At Risk", "low",
      "Elevated heart rate — possible early cardiac stress. Avoid stimulants, rest adequately, and schedule a cardiac check-up.",
      alerts, details, v);
  }

  if (lowHR) {
    return build("Heart Disease", "At Risk", "medium",
      "Your heart rate is below normal (bradycardia). This can be normal for athletes but requires medical evaluation. Consult a cardiologist.",
      alerts, details, v);
  }

  // Branch D: High temperature only
  if (tempAbn) {
    if (breathSh) {
      return build("Asthma", "At Risk", "medium",
        "Elevated temperature with shortness of breath — consistent with respiratory infection or asthma exacerbation. Consult your doctor.",
        alerts, details, v);
    }
    return build("Diabetes Mellitus", "At Risk", "low",
      "Body temperature elevated — a common indicator in Diabetes Mellitus monitoring. Maintain a low-sugar diet and schedule a physician check-up.",
      alerts, details, v);
  }

  // Branch E: Symptom flags only (all vitals normal)
  if (chestPain || breathSh) {
    return build("Heart Disease", "At Risk", v.familyHistory ? "medium" : "low",
      "Your vitals are currently normal, but reported chest pain/shortness of breath warrants attention. Schedule a cardiac evaluation as a precaution.",
      alerts, details, v);
  }

  // Branch F: All Normal — use quantum scores as tiebreaker
  const qScores = quantumConfidenceScores(v);
  const topQ = Object.entries(qScores).sort((a, b) => b[1] - a[1])[0];
  if (topQ[0] !== "Healthy" && topQ[1] > 20) {
    // Quantum model detects subtle signal — flag as low risk
    return build(topQ[0] as Disease, "At Risk", "low",
      `All core vitals are normal. However, Quantum AI detected a subtle ${topQ[0]} pattern (${topQ[1]}% confidence). Consider a preventive check-up.`,
      alerts, details, v);
  }

  return build("Healthy", "Normal", "low",
    "All vitals are within normal range — excellent! Keep maintaining a healthy lifestyle: balanced diet, regular exercise, and annual checkups.",
    alerts, details, v);
}
