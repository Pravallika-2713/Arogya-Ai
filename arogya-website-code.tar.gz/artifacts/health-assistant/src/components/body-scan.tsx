import { motion } from "framer-motion";
import { Activity } from "lucide-react";

export function BodyScanAnimation() {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.5 }}
      className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-background/80 backdrop-blur-md rounded-3xl"
    >
      <div className="relative w-64 h-64 flex items-center justify-center">
        {/* Pulsing rings */}
        <motion.div
          animate={{ scale: [1, 1.5, 2], opacity: [0.8, 0.3, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
          className="absolute inset-0 rounded-full border-4 border-primary/50"
        />
        <motion.div
          animate={{ scale: [1, 1.8, 2.5], opacity: [0.5, 0.2, 0] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeOut", delay: 0.5 }}
          className="absolute inset-0 rounded-full border-2 border-primary/30"
        />
        
        {/* Center Icon */}
        <div className="relative z-10 w-24 h-24 bg-white rounded-full shadow-2xl flex items-center justify-center border border-border">
          <Activity size={48} className="text-primary animate-pulse" />
        </div>
      </div>
      
      <motion.div
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 1.5, repeat: Infinity }}
        className="mt-12 text-center"
      >
        <h2 className="text-2xl font-display font-bold text-foreground">Analyzing Body Vitals</h2>
        <p className="text-muted-foreground mt-2">Running AI prediction models...</p>
      </motion.div>
    </motion.div>
  );
}
