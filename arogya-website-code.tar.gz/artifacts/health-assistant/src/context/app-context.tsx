import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export type VoiceLang = "en" | "te";

export interface UserProfile {
  name: string;
  phone: string;
  age: string;
  gender: string;
}

interface AppContextValue {
  lang: VoiceLang;
  setLang: (l: VoiceLang) => void;
  user: UserProfile | null;
  setUser: (u: UserProfile) => void;
  clearUser: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_KEY_LANG = "arogya_lang";
const STORAGE_KEY_USER = "arogya_user";

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<VoiceLang>(() => {
    return (localStorage.getItem(STORAGE_KEY_LANG) as VoiceLang) ?? "en";
  });

  const [user, setUserState] = useState<UserProfile | null>(() => {
    try {
      const s = localStorage.getItem(STORAGE_KEY_USER);
      return s ? JSON.parse(s) : null;
    } catch { return null; }
  });

  const setLang = (l: VoiceLang) => {
    setLangState(l);
    localStorage.setItem(STORAGE_KEY_LANG, l);
  };

  const setUser = (u: UserProfile) => {
    setUserState(u);
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(u));
  };

  const clearUser = () => {
    setUserState(null);
    localStorage.removeItem(STORAGE_KEY_USER);
  };

  return (
    <AppContext.Provider value={{ lang, setLang, user, setUser, clearUser }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppContext must be used within AppProvider");
  return ctx;
}
